"use client"

import { useEffect, useRef, useCallback } from "react"

interface Particle {
  x: number
  y: number
  size: number
  opacity: number
  vx: number // Velocity x
  vy: number // Velocity y
  color: string
  life: number // Remaining life
  initialLife: number
  isBurst?: boolean
}

const GOLD_COLORS = ["#FFD700", "#FFAA00", "#DAA520", "#F0E68C", "#B8860B", "#FFC400", "#FFB347"]
const BURST_COLORS = ["#FFFACD", "#FFEFD5", "#FFE4B5", "#FFDEAD", "#FFDAB9"]

// Physics Constants
const NORMAL_GRAVITY = 0.01
const BURST_GRAVITY = 0.07 // Increased gravity for burst particles
const NORMAL_DRAG_FACTOR = 0.995 // Slight drag
const BURST_DRAG_FACTOR = 0.96 // Stronger drag for burst particles

export default function MouseTrail() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const particlesRef = useRef<Particle[]>([])
  const animationFrameIdRef = useRef<number | null>(null)

  const createParticle = useCallback((x: number, y: number, isBurst = false) => {
    let size, life, opacity, vx, vy, color

    if (isBurst) {
      size = Math.random() * 3.5 + 2.5
      life = Math.random() * 45 + 30 // Slightly longer life for burst to see physics
      opacity = 1
      vx = (Math.random() - 0.5) * 5 // Increased initial horizontal speed for burst
      vy = (Math.random() - 0.5) * 4 - 1.5 // Initial upward thrust for burst
      color = BURST_COLORS[Math.floor(Math.random() * BURST_COLORS.length)]
    } else {
      size = Math.random() * 2 + 1
      life = Math.random() * 50 + 30
      opacity = 0.9
      vx = (Math.random() - 0.5) * 1.8
      vy = (Math.random() - 0.5) * 1.8 - 0.6
      color = GOLD_COLORS[Math.floor(Math.random() * GOLD_COLORS.length)]
    }

    return {
      x,
      y,
      size,
      opacity,
      vx,
      vy,
      color,
      life,
      initialLife: life,
      isBurst,
    }
  }, [])

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    ctx.clearRect(0, 0, canvas.width, canvas.height)

    particlesRef.current = particlesRef.current
      .map((p) => {
        // Apply Drag
        p.vx *= p.isBurst ? BURST_DRAG_FACTOR : NORMAL_DRAG_FACTOR
        p.vy *= p.isBurst ? BURST_DRAG_FACTOR : NORMAL_DRAG_FACTOR

        // Apply Gravity
        p.vy += p.isBurst ? BURST_GRAVITY : NORMAL_GRAVITY

        // Update position
        p.x += p.vx
        p.y += p.vy
        p.life -= 1

        p.opacity = Math.max(0, (p.life / p.initialLife) * (p.isBurst ? 1 : 0.8))
        const sizeFactor = p.isBurst ? p.initialLife / 18 : p.initialLife / 35 // Burst particles shrink a bit faster
        p.size = Math.max(0, (p.life / p.initialLife) * sizeFactor)

        if (p.life > 0 && p.opacity > 0.01 && p.size > 0.1) {
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2, false)
          ctx.fillStyle = hexToRgba(p.color, p.opacity)

          ctx.shadowColor = hexToRgba(p.color, p.opacity * (p.isBurst ? 0.8 : 0.6))
          ctx.shadowBlur = p.size * (p.isBurst ? 3.5 : 2.5)

          ctx.fill()
          ctx.shadowColor = "transparent"
          ctx.shadowBlur = 0
          return p
        }
        return null
      })
      .filter(Boolean) as Particle[]

    animationFrameIdRef.current = requestAnimationFrame(draw)
  }, [])

  const hexToRgba = (hex: string, alpha: number): string => {
    const r = Number.parseInt(hex.slice(1, 3), 16)
    const g = Number.parseInt(hex.slice(3, 5), 16)
    const b = Number.parseInt(hex.slice(5, 7), 16)
    return `rgba(${r}, ${g}, ${b}, ${alpha})`
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const setCanvasDimensions = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    setCanvasDimensions()
    window.addEventListener("resize", setCanvasDimensions)

    const handleMouseMove = (event: MouseEvent) => {
      const { clientX, clientY } = event

      const elementUnderCursor = document.elementFromPoint(clientX, clientY)
      const isInteractive = elementUnderCursor?.closest('[data-interactive-trail="true"]')

      const particlesToCreate = isInteractive ? 6 : 2 // Slightly more particles for burst
      const particleTypeBurst = !!isInteractive

      for (let i = 0; i < particlesToCreate; i++) {
        if (particlesRef.current.length < 300) {
          const spawnX = clientX + (Math.random() - 0.5) * (particleTypeBurst ? 10 : 5)
          const spawnY = clientY + (Math.random() - 0.5) * (particleTypeBurst ? 10 : 5)
          particlesRef.current.push(createParticle(spawnX, spawnY, particleTypeBurst))
        }
      }
    }
    window.addEventListener("mousemove", handleMouseMove)

    animationFrameIdRef.current = requestAnimationFrame(draw)

    return () => {
      window.removeEventListener("resize", setCanvasDimensions)
      window.removeEventListener("mousemove", handleMouseMove)
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current)
      }
      particlesRef.current = []
    }
  }, [draw, createParticle])

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        pointerEvents: "none",
        zIndex: 9999,
      }}
    />
  )
}
