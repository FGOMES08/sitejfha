"use client"

import Link from "next/link"

import { cn } from "@/lib/utils"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronRight, Briefcase, TrendingUp, Shield, CheckCircle, Globe, Target, Award } from "lucide-react"

export default function ServicesPage() {
  const [activeCategory, setActiveCategory] = useState<string | null>("strategic-consulting") // Default open

  const serviceCategories = [
    {
      id: "strategic-consulting",
      title: "Strategic Consulting",
      icon: <Briefcase className="w-8 h-8 text-primary" />,
      description:
        "Expert guidance for complex corporate strategies and high-stakes negotiations, ensuring optimal outcomes.",
      color: "primary", // Use Tailwind color names or CSS vars
      services: [
        {
          name: "Joint Ventures & Corporate Alliances",
          description:
            "Architecting and structuring strategic partnerships to foster mutual growth, innovation, and market expansion.",
          benefits: [
            "Identify and vet optimal partnership opportunities",
            "Structure equitable and synergistic agreements",
            "Maximize shared growth potential and market penetration",
            "Ensure robust legal and financial alignment",
          ],
        },
        {
          name: "High-Value Negotiations",
          description:
            "Expert representation in large-scale corporate negotiations, safeguarding client interests and maximizing value.",
          benefits: [
            "Employ sophisticated negotiation strategies",
            "Protect and advance client interests vigorously",
            "Achieve optimal deal terms and conditions",
            "Facilitate complex multi-party agreements with finesse",
          ],
        },
      ],
    },
    {
      id: "financial-instruments",
      title: "Financial Instruments & Solutions",
      icon: <TrendingUp className="w-8 h-8 text-primary" />,
      description:
        "Comprehensive financial instruments for international operations, complex transactions, and risk mitigation.",
      color: "primary",
      services: [
        {
          name: "Letters of Credit (LCs)",
          description:
            "Structuring and issuing Letters of Credit to secure and facilitate international trade operations.",
          benefits: [
            "Secure international trade transactions effectively",
            "Minimize payment and performance risks",
            "Facilitate seamless cross-border commerce",
            "Ensure full compliance with international regulations (UCP 600)",
          ],
        },
        {
          name: "Bank Guarantees (BGs)",
          description:
            "Managing high-value bank guarantees to ensure security, liquidity, and performance for complex transactions.",
          benefits: [
            "Enhance transaction security and assurance",
            "Improve liquidity management and cash flow",
            "Implement robust risk mitigation strategies",
            "Provide flexible and tailored guarantee structures",
          ],
        },
        {
          name: "Standby Letters of Credit (SBLCs)",
          description:
            "Issuing and managing SBLCs to guarantee financial obligations and performance in global markets.",
          benefits: [
            "Unlock global market access and opportunities",
            "Provide strong payment security assurance",
            "Enhance corporate creditworthiness and reputation",
            "Offer versatile and adaptable financing options",
          ],
        },
        {
          name: "Public & Private Securities (Notes & Bonds)",
          description:
            "Advisory on structuring, issuing, and managing debt securities for capital raising and refinancing.",
          benefits: [
            "Design optimal capital structure strategies",
            "Leverage market timing and issuance expertise",
            "Navigate complex regulatory compliance landscapes",
            "Manage investor relations and market perception",
          ],
        },
      ],
    },
    {
      id: "capital-advisory",
      title: "Capital Advisory & Investment",
      icon: <Shield className="w-8 h-8 text-primary" />,
      description:
        "Exclusive access to premium investment opportunities and bespoke capital solutions for growth and wealth preservation.",
      color: "primary",
      services: [
        {
          name: "Private Placement Programs (PPP)",
          description:
            "Facilitating access to exclusive, high-yield private investment programs with robust financial leverage capabilities.",
          benefits: [
            "Access to highly exclusive investment opportunities",
            "Potential for significant, risk-managed returns",
            "Leverage institutional-grade financial instruments",
            "Strict confidentiality and due diligence protocols",
          ],
        },
        {
          name: "Mergers & Acquisitions (M&A)",
          description: "End-to-end advisory for buy-side and sell-side M&A transactions, from strategy to integration.",
          benefits: [
            "Strategic target identification and valuation",
            "Expert deal structuring and negotiation",
            "Comprehensive due diligence and risk assessment",
            "Seamless post-merger integration support",
          ],
        },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground section-padding">
      <div className="container-max">
        {/* Hero Section */}
        <section className="text-center mb-16 md:mb-24 fade-in-up">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-gold mb-6">Our Premier Services</h1>
          <p className="font-body text-lg md:text-xl text-foreground/80 max-w-4xl mx-auto">
            Delivering comprehensive financial solutions and strategic advisory, meticulously designed to unlock
            exceptional value and drive sustainable growth for our esteemed clientele.
          </p>
        </section>

        {/* Service Categories Overview */}
        <section className="mb-16 md:mb-20">
          <div className="grid md:grid-cols-3 gap-8">
            {serviceCategories.map((category) => (
              <Card
                key={category.id}
                className={cn(
                  "cursor-pointer hover-lift-subtle glass-pane fade-in-up",
                  activeCategory === category.id ? "ring-2 ring-primary shadow-elegant-lg" : "border-border/70",
                )}
                onClick={() => setActiveCategory(activeCategory === category.id ? null : category.id)}
                style={{ animationDelay: `${0.2 + serviceCategories.indexOf(category) * 0.1}s` }}
              >
                <CardHeader className="items-center text-center">
                  <div className={`p-3 rounded-full bg-primary/10 mb-4`}>{category.icon}</div>
                  <CardTitle className="text-xl md:text-2xl">{category.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="font-body text-sm text-foreground/70 mb-4">{category.description}</p>
                  <div className="flex items-center justify-center text-sm font-medium text-white hover:text-white/80 transition-colors">
                    <span>{activeCategory === category.id ? "Hide Details" : "Explore Services"}</span>
                    <ChevronRight
                      className={cn("w-4 h-4 ml-1 transition-transform", activeCategory === category.id && "rotate-90")}
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Detailed Services Section */}
        {activeCategory && (
          <section className="mb-16 md:mb-24">
            {serviceCategories
              .filter((cat) => cat.id === activeCategory)
              .map((category) => (
                <div key={category.id} className="fade-in-up" style={{ animationDelay: "0.2s" }}>
                  <div className="text-center mb-12 md:mb-16">
                    <h2 className="font-heading text-3xl md:text-4xl text-gold mb-4">{category.title}</h2>
                    <p className="font-body text-lg text-foreground/80 max-w-3xl mx-auto">{category.description}</p>
                  </div>

                  <div className="grid gap-8">
                    {category.services.map((service, index) => (
                      <Card
                        key={index}
                        className="glass-pane hover-lift-subtle fade-in-up"
                        style={{ animationDelay: `${0.3 + index * 0.1}s` }}
                      >
                        <CardHeader>
                          <CardTitle className="text-xl md:text-2xl">{service.name}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="font-body text-md text-foreground/80 mb-6">{service.description}</p>
                          <h4 className="font-heading text-sm font-semibold text-white uppercase tracking-wider mb-3">
                            Key Benefits & Features
                          </h4>
                          <ul className="space-y-2 font-body text-sm text-foreground/70">
                            {service.benefits.map((benefit, idx) => (
                              <li key={idx} className="flex items-start">
                                <CheckCircle className="w-4 h-4 text-primary mr-2 mt-0.5 flex-shrink-0" />
                                {benefit}
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
          </section>
        )}

        {/* Value Proposition Section */}
        <section className="mb-16 md:mb-24">
          <Card className="text-center fade-in-up glass-pane hover-lift-subtle" style={{ animationDelay: "0.2s" }}>
            <CardHeader>
              <CardTitle className="text-3xl md:text-4xl">Why Entrust JFHA With Your Vision?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-body text-lg text-foreground/80 max-w-4xl mx-auto mb-10">
                Our services are meticulously crafted with a singular objective: delivering exceptional, enduring value
                through strategic intelligence, technical mastery, and an unwavering dedication to our clients' triumph.
              </p>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {[
                  {
                    title: "Global Reach",
                    desc: "Access to international markets and opportunities",
                    icon: <Globe className="w-8 h-8 text-primary" />,
                  },
                  {
                    title: "Precision & Tailoring",
                    desc: "Bespoke solutions for specific business needs",
                    icon: <Target className="w-8 h-8 text-primary" />,
                  },
                  {
                    title: "Security & Discretion",
                    desc: "Risk-managed approaches with utmost confidentiality",
                    icon: <Shield className="w-8 h-8 text-primary" />,
                  },
                  {
                    title: "Proven Results",
                    desc: "Track record of exceptional, sustainable outcomes",
                    icon: <Award className="w-8 h-8 text-primary" />,
                  },
                ].map((item, index) => (
                  <div key={index} className="fade-in-up" style={{ animationDelay: `${0.4 + index * 0.1}s` }}>
                    <div className="mx-auto mb-3">{item.icon}</div>
                    <h4 className="font-heading text-lg font-semibold text-white mb-1">{item.title}</h4>
                    <p className="font-body text-sm text-foreground/70">{item.desc}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {/* CTA Section */}
        <section className="text-center fade-in-up" style={{ animationDelay: "0.2s" }}>
          <h2 className="font-heading text-3xl md:text-4xl text-gold mb-6">
            Ready to Elevate Your Financial Strategy?
          </h2>
          <p className="font-body text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
            Discover how our comprehensive suite of services can transform your business operations and unlock new
            horizons for growth and prosperity.
          </p>
          <Link href="/contact" passHref>
            <Button size="lg" className="font-body tracking-wide">
              Schedule a Confidential Consultation
            </Button>
          </Link>
        </section>
      </div>
    </div>
  )
}
