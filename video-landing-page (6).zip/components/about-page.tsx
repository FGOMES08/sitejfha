"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Target, Lock, Star, Building, Users, BarChart3, ShieldCheck, Handshake } from "lucide-react" // Added more icons
import { CheckCircle } from "lucide-react"

export default function AboutPage() {
  const values = [
    {
      title: "Unwavering Ethics",
      description: "Absolute integrity and transparency in every operation and interaction.",
      icon: <ShieldCheck className="w-10 h-10 text-primary" />,
      details:
        "We uphold the highest ethical standards, ensuring all dealings are conducted with honesty and fairness, building lasting trust.",
    },
    {
      title: "Steadfast Confidentiality",
      description: "Guaranteed discretion and protection of sensitive information at all stages.",
      icon: <Lock className="w-10 h-10 text-primary" />,
      details:
        "Your privacy is paramount. We employ rigorous security protocols to safeguard your information with utmost confidentiality.",
    },
    {
      title: "Pursuit of Excellence",
      description: "Commitment to delivering measurable results and consistently superior performance.",
      icon: <Star className="w-10 h-10 text-primary" />,
      details:
        "We strive for excellence in every endeavor, leveraging strategic insights and meticulous execution to achieve exceptional outcomes.",
    },
  ]

  const expertiseAreas = [
    "Financial Markets Analysis",
    "Mergers & Acquisitions",
    "Private Equity Structuring",
    "Business Strategy Development",
    "Financial Structuring",
    "Risk Analysis & Management",
    "Investment Advisory",
    "Corporate Finance",
    "International Trade Finance",
    "Asset Management",
  ]

  return (
    <div className="min-h-screen bg-background text-foreground section-padding">
      <div className="container-max">
        {/* Hero Section */}
        <section className="text-center mb-16 md:mb-24 fade-in-up">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-gold mb-6">About JFHA Private Group</h1>
          <p className="font-body text-lg md:text-xl text-foreground/80 max-w-4xl mx-auto">
            Pioneering the future of high-level business consulting and brokerage through unwavering trust, profound
            expertise, and bespoke financial solutions.
          </p>
        </section>

        {/* Vision & Mission Section */}
        <section className="mb-16 md:mb-24 grid lg:grid-cols-2 gap-8 md:gap-12">
          <Card className="fade-in-up hover-lift-subtle glass-pane" style={{ animationDelay: "0.2s" }}>
            <CardHeader>
              <div className="flex items-center mb-3">
                <Target className="w-8 h-8 text-primary mr-3" />
                <CardTitle className="text-2xl md:text-3xl">Our Vision</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="font-body text-lg text-foreground/80 mb-4">
                To be the preeminent global reference in high-level business consulting and brokerage, distinguished by
                our integrity, personalized approach, and transformative results.
              </p>
              <blockquote className="border-l-4 border-primary pl-4 italic text-foreground/70">
                "We envision a financial landscape where strategic intelligence and ethical principles converge to
                unlock unparalleled opportunities for growth and success."
              </blockquote>
            </CardContent>
          </Card>

          <Card className="fade-in-up hover-lift-subtle glass-pane" style={{ animationDelay: "0.4s" }}>
            <CardHeader>
              <div className="flex items-center mb-3">
                <Handshake className="w-8 h-8 text-primary mr-3" />
                <CardTitle className="text-2xl md:text-3xl">Our Mission</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="font-body text-lg text-foreground/80 mb-4">
                To empower companies, investors, and executives with strategic financial solutions, fostering
                sustainable growth and exceptional value through an ethical, insightful, and results-driven methodology.
              </p>
              <ul className="space-y-2 font-body text-foreground/80">
                {["Strategic Solutions", "Ethical Approach", "Sustainable Results", "Client-Centric Focus"].map(
                  (item) => (
                    <li key={item} className="flex items-center">
                      <CheckCircle className="w-5 h-5 text-primary mr-2 flex-shrink-0" /> {item}
                    </li>
                  ),
                )}
              </ul>
            </CardContent>
          </Card>
        </section>

        {/* Core Values Section */}
        <section className="mb-16 md:mb-24">
          <div className="text-center mb-12 md:mb-16 fade-in-up" style={{ animationDelay: "0.2s" }}>
            <h2 className="font-heading text-3xl md:text-4xl text-gold mb-4">Our Core Values</h2>
            <p className="font-body text-lg text-foreground/80 max-w-3xl mx-auto">
              These fundamental principles are the bedrock of our operations, guiding every decision and relationship.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <Card
                key={index}
                className="text-center fade-in-up hover-lift-subtle glass-pane"
                style={{ animationDelay: `${0.4 + index * 0.2}s` }}
              >
                <CardHeader>
                  <div className="mx-auto mb-4">{value.icon}</div>
                  <CardTitle className="text-xl md:text-2xl">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-body text-md font-semibold text-foreground/90 mb-3">{value.description}</p>
                  <p className="font-body text-sm text-foreground/70">{value.details}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Foundation & Expertise Section */}
        <section className="mb-16 md:mb-24">
          <div className="text-center mb-12 md:mb-16 fade-in-up" style={{ animationDelay: "0.2s" }}>
            <h2 className="font-heading text-3xl md:text-4xl text-gold mb-4">Foundation & Expertise</h2>
            <p className="font-body text-lg text-foreground/80 max-w-4xl mx-auto">
              Forged from decades of collective experience in global financial markets, our multidisciplinary expertise
              combines profound market knowledge with technical acumen to deliver unparalleled results.
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-start">
            <Card className="fade-in-up hover-lift-subtle glass-pane" style={{ animationDelay: "0.4s" }}>
              <CardHeader>
                <div className="flex items-center mb-3">
                  <Building className="w-8 h-8 text-primary mr-3" />
                  <CardTitle className="text-2xl md:text-3xl">Our Origins</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="font-body text-foreground/80 mb-4">
                  JFHA Private Group was established by seasoned professionals with extensive backgrounds in financial
                  markets, M&A, and private equity. Our founders unite decades of experience from leading global
                  financial institutions and advisory firms.
                </p>
                <p className="font-body text-foreground/80">
                  This rich heritage underpins our multidisciplinary approach, seamlessly integrating business strategy,
                  financial structuring, and specialized risk analysis to provide comprehensive, holistic solutions.
                </p>
              </CardContent>
            </Card>

            <div className="fade-in-up" style={{ animationDelay: "0.6s" }}>
              <h3 className="font-heading text-2xl md:text-3xl text-gold mb-6">Areas of Expertise</h3>
              <div className="flex flex-wrap gap-3 mb-8">
                {expertiseAreas.map((area, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="px-4 py-2 text-sm font-body border-primary/30 bg-primary/10 text-white hover:bg-primary/20 transition-colors"
                  >
                    {area}
                  </Badge>
                ))}
              </div>
              <Card className="bg-primary/5 border-primary/20 hover-lift-subtle">
                <CardContent className="p-6">
                  <h4 className="font-heading text-xl font-semibold text-white mb-3">Our Competitive Edge</h4>
                  <p className="font-body text-sm text-foreground/80">
                    We fuse visionary market insight with rigorous technical knowledge to engineer secure, high-return
                    operations. Our capacity to transcend conventional boundaries enables us to identify unique
                    opportunities and architect innovative solutions that deliver exceptional, enduring value.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Multidisciplinary Approach Section */}
        <section>
          <Card className="text-center fade-in-up glass-pane hover-lift-subtle" style={{ animationDelay: "0.2s" }}>
            <CardHeader>
              <CardTitle className="text-3xl md:text-4xl">Our Multidisciplinary Approach</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-body text-lg text-foreground/80 max-w-4xl mx-auto mb-10">
                We transcend traditional advisory; we become your strategic partners. By integrating deep industry
                knowledge with innovative thinking, we craft bespoke solutions that drive sustainable growth and
                superior returns.
              </p>
              <div className="grid md:grid-cols-3 gap-8">
                {[
                  {
                    title: "Business Strategy",
                    icon: <BarChart3 className="w-10 h-10 text-primary" />,
                    desc: "Strategic planning and market positioning",
                  },
                  {
                    title: "Financial Structuring",
                    icon: <Users className="w-10 h-10 text-primary" />,
                    desc: "Optimal capital structure and financing solutions",
                  },
                  {
                    title: "Risk Analysis",
                    icon: <ShieldCheck className="w-10 h-10 text-primary" />,
                    desc: "Comprehensive risk assessment and mitigation",
                  },
                ].map((item, index) => (
                  <div key={index} className="fade-in-up" style={{ animationDelay: `${0.4 + index * 0.1}s` }}>
                    <div className="mx-auto mb-4">{item.icon}</div>
                    <h4 className="font-heading text-xl font-semibold text-white mb-2">{item.title}</h4>
                    <p className="font-body text-sm text-foreground/70">{item.desc}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  )
}
