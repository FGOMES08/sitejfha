"use client"

import { CardDescription } from "@/components/ui/card"

import type React from "react"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { format } from "date-fns"
import {
  CalendarIcon,
  Mail,
  MapPin,
  Phone,
  Globe,
  MessageSquare,
  Send,
  CheckCircle,
  Languages,
  Building,
} from "lucide-react"
import Link from "next/link"

export default function ContactPage() {
  const [formData, setFormData] = useState({ name: "", email: "", company: "", subject: "", message: "" })
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [timeSlot, setTimeSlot] = useState<string>("")
  const [chatMessages, setChatMessages] = useState<{ sender: string; message: string; time: string }[]>([
    {
      sender: "bot",
      message: "Welcome to JFHA. How may I assist you today?",
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ])
  const [chatInput, setChatInput] = useState("")
  const [formSubmitted, setFormSubmitted] = useState(false)
  const [consultationBooked, setConsultationBooked] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    setFormSubmitted(true)
    setTimeout(() => {
      setFormSubmitted(false)
      setFormData({ name: "", email: "", company: "", subject: "", message: "" })
    }, 5000)
  }

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!chatInput.trim()) return
    const userMessage = {
      sender: "user",
      message: chatInput,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }
    setChatMessages((prev) => [...prev, userMessage])
    setChatInput("")
    // Simplified bot response
    setTimeout(() => {
      const botResponse =
        "Thank you for your message. A representative will be with you shortly. For urgent matters, please use our contact form or schedule a consultation."
      setChatMessages((prev) => [
        ...prev,
        {
          sender: "bot",
          message: botResponse,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ])
    }, 1000)
  }

  const handleBookConsultation = () => {
    if (!date || !timeSlot) return
    console.log("Consultation booked for:", format(date, "PPP"), "at", timeSlot)
    setConsultationBooked(true)
    setTimeout(() => {
      setConsultationBooked(false)
      setDate(undefined)
      setTimeSlot("")
    }, 5000)
  }

  const contactMethods = [
    {
      icon: <Mail className="w-6 h-6 text-primary" />,
      title: "Email Us",
      content: "contato@jfha.com.br",
      href: "mailto:contato@jfha.com.br",
    },
    {
      icon: <Phone className="w-6 h-6 text-primary" />,
      title: "Call Us",
      content: "(+55 11) XXXX-XXXX",
      href: "tel:+551100000000",
    },
    {
      icon: <Building className="w-6 h-6 text-primary" />,
      title: "Headquarters",
      content: "Barueri, São Paulo, Brazil",
    },
    {
      icon: <Globe className="w-6 h-6 text-primary" />,
      title: "Website",
      content: "www.jfha.com.br",
      href: "https://www.jfha.com.br",
      target: "_blank",
    },
  ]

  const strategicLocations = [
    {
      name: "Brasília, DF",
      role: "Federal Capital Access",
      description: "Strategic presence for governmental and regulatory liaison.",
    },
    {
      name: "São Paulo, SP",
      role: "Financial Epicenter",
      description: "Connecting clients with Brazil's largest financial market.",
    },
    {
      name: "Balneário Camboriú, SC",
      role: "Luxury Investment Hub",
      description: "Serving HNW clients and premium investment opportunities.",
    },
  ]

  const timeZoneSupport = [
    { region: "Americas (BRT)", hours: "08:00 - 20:00", examples: "NYC: 07:00-19:00 | LA: 04:00-16:00" },
    { region: "Europe (CET)", hours: "12:00 - 00:00", examples: "London: 11:00-23:00 | Frankfurt: 12:00-00:00" },
    { region: "Asia-Pacific (SGT)", hours: "19:00 - 07:00", examples: "Singapore: 19:00-07:00 | Tokyo: 20:00-08:00" },
    { region: "Middle East (GST)", hours: "14:00 - 02:00", examples: "Dubai: 14:00-02:00 | Riyadh: 13:00-01:00" },
  ]

  const languagesSupported = [
    { lang: "Portuguese", level: "Native", flag: "🇧🇷" },
    { lang: "English", level: "Fluent", flag: "🇺🇸/🇬🇧" },
    { lang: "Spanish", level: "Fluent", flag: "🇪🇸" },
    { lang: "French", level: "Professional", flag: "🇫🇷" },
    { lang: "German", level: "Professional", flag: "🇩🇪" },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground section-padding">
      <div className="container-max">
        {/* Hero Section */}
        <section className="text-center mb-16 md:mb-24 fade-in-up">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-gold mb-6">Connect With JFHA</h1>
          <p className="font-body text-lg md:text-xl text-foreground/80 max-w-4xl mx-auto">
            Reach out to our team of distinguished experts to explore how JFHA can elevate your financial and strategic
            objectives to new echelons of success.
          </p>
        </section>

        {/* Contact Methods Grid */}
        <section className="mb-16 md:mb-20 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {contactMethods.map((method, index) => (
            <Card
              key={index}
              className="text-center fade-in-up hover-lift-subtle glass-pane"
              style={{ animationDelay: `${0.2 + index * 0.1}s` }}
            >
              <CardHeader className="items-center">
                <div className="p-3 rounded-full bg-primary/10 mb-3">{method.icon}</div>
                <CardTitle className="text-lg md:text-xl">{method.title}</CardTitle>
              </CardHeader>
              <CardContent>
                {method.href ? (
                  <Link
                    href={method.href}
                    target={method.target}
                    className="font-body text-sm text-foreground/80 hover:text-primary transition-colors break-all"
                  >
                    {method.content}
                  </Link>
                ) : (
                  <p className="font-body text-sm text-foreground/80">{method.content}</p>
                )}
              </CardContent>
            </Card>
          ))}
        </section>

        {/* Strategic Presence & Global Support */}
        <section className="mb-16 md:mb-20 grid lg:grid-cols-2 gap-8 md:gap-12">
          <Card className="fade-in-up hover-lift-subtle glass-pane" style={{ animationDelay: "0.2s" }}>
            <CardHeader>
              <div className="flex items-center mb-2">
                <MapPin className="w-7 h-7 text-primary mr-3" />
                <CardTitle className="text-xl md:text-2xl">Our Strategic Presence</CardTitle>
              </div>
              <CardDescription>
                Positioned to serve clients across Brazil and internationally with personalized, high-quality service.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {strategicLocations.map((loc) => (
                <div key={loc.name}>
                  <h4 className="font-heading text-md font-semibold text-white">
                    {loc.name} <span className="text-xs text-muted-foreground font-body">({loc.role})</span>
                  </h4>
                  <p className="font-body text-sm text-foreground/70">{loc.description}</p>
                </div>
              ))}
            </CardContent>
          </Card>
          <Card className="fade-in-up hover-lift-subtle glass-pane" style={{ animationDelay: "0.4s" }}>
            <CardHeader>
              <div className="flex items-center mb-2">
                <Globe className="w-7 h-7 text-primary mr-3" />
                <CardTitle className="text-xl md:text-2xl">Global Time Zone Coverage</CardTitle>
              </div>
              <CardDescription>Dedicated support across multiple time zones for our global clientele.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {timeZoneSupport.map((tz) => (
                <div key={tz.region}>
                  <h4 className="font-heading text-md font-semibold text-white">{tz.region}</h4>
                  <p className="font-body text-sm text-foreground/70">Support: {tz.hours}</p>
                  <p className="font-body text-xs text-muted-foreground">{tz.examples}</p>
                </div>
              ))}
              <div className="pt-3 border-t border-border/50">
                <h4 className="font-heading text-md font-semibold text-white flex items-center">
                  <Languages className="w-5 h-5 mr-2" />
                  Multilingual Support
                </h4>
                <p className="font-body text-sm text-foreground/70 mt-1">
                  {languagesSupported.map((l) => `${l.flag} ${l.lang} (${l.level})`).join(" • ")}. Professional
                  translation services available.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Contact Tabs Section */}
        <section className="mb-16 md:mb-20 fade-in-up" style={{ animationDelay: "0.2s" }}>
          <Tabs defaultValue="form" className="w-full">
            <TabsList className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-8 bg-secondary p-1 rounded-lg">
              {["Contact Form", "Live Chat (Simulated)", "Schedule Consultation"].map((label, i) => (
                <TabsTrigger
                  key={label}
                  value={["form", "chat", "schedule"][i]}
                  className="font-body data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md hover:bg-primary/10 transition-all"
                >
                  {label}
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value="form">
              <Card className="glass-pane">
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl md:text-3xl">Send Us a Message</CardTitle>
                  <CardDescription>We typically respond within one business day.</CardDescription>
                </CardHeader>
                <CardContent>
                  {formSubmitted ? (
                    <div className="text-center py-8">
                      <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                      <h3 className="font-heading text-2xl text-green-500 mb-2">Message Sent!</h3>
                      <p className="font-body text-foreground/80">
                        Thank you for your inquiry. We will contact you shortly.
                      </p>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6 font-body">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-1.5">
                          <Label htmlFor="name" className="text-foreground/80">
                            Full Name
                          </Label>
                          <Input
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            placeholder="e.g., John Doe"
                            required
                            className="bg-secondary/50 border-border/70 focus:border-primary"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="email" className="text-foreground/80">
                            Email
                          </Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            placeholder="e.g., john.doe@example.com"
                            required
                            className="bg-secondary/50 border-border/70 focus:border-primary"
                          />
                        </div>
                      </div>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-1.5">
                          <Label htmlFor="company" className="text-foreground/80">
                            Company (Optional)
                          </Label>
                          <Input
                            id="company"
                            name="company"
                            value={formData.company}
                            onChange={handleInputChange}
                            placeholder="e.g., Example Corp"
                            className="bg-secondary/50 border-border/70 focus:border-primary"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="subject" className="text-foreground/80">
                            Subject
                          </Label>
                          <Input
                            id="subject"
                            name="subject"
                            value={formData.subject}
                            onChange={handleInputChange}
                            placeholder="e.g., Inquiry about Services"
                            required
                            className="bg-secondary/50 border-border/70 focus:border-primary"
                          />
                        </div>
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="message" className="text-foreground/80">
                          Message
                        </Label>
                        <Textarea
                          id="message"
                          name="message"
                          value={formData.message}
                          onChange={handleInputChange}
                          placeholder="Please describe your inquiry in detail..."
                          required
                          rows={5}
                          className="bg-secondary/50 border-border/70 focus:border-primary"
                        />
                      </div>
                      <Button type="submit" size="lg" className="w-full">
                        Send Message
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chat">
              <Card className="glass-pane">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div className="flex items-center">
                    <MessageSquare className="w-6 h-6 text-primary mr-3" />
                    <CardTitle className="text-xl md:text-2xl">Live Assistant</CardTitle>
                  </div>
                  <span className="text-xs text-green-500 font-semibold flex items-center">
                    <span className="w-2 h-2 bg-green-500 rounded-full mr-1.5"></span>Online
                  </span>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col h-[400px] bg-secondary/30 rounded-md">
                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                      {chatMessages.map((msg, index) => (
                        <div key={index} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                          <div
                            className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${msg.sender === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                          >
                            <p>{msg.message}</p>
                            <p
                              className={`text-xs mt-1 ${msg.sender === "user" ? "text-primary-foreground/70" : "text-muted-foreground/70"} text-right`}
                            >
                              {msg.time}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <form onSubmit={handleChatSubmit} className="flex items-center p-3 border-t border-border/50">
                      <Input
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        placeholder="Type your message..."
                        className="flex-1 bg-background/50 border-border/70 focus:border-primary"
                      />
                      <Button type="submit" size="icon" className="ml-2">
                        <Send className="w-4 h-4" />
                      </Button>
                    </form>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="schedule">
              <Card className="glass-pane">
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl md:text-3xl">Schedule a Consultation</CardTitle>
                  <CardDescription>Select a preferred date and time to speak with our experts.</CardDescription>
                </CardHeader>
                <CardContent>
                  {consultationBooked ? (
                    <div className="text-center py-8">
                      <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                      <h3 className="font-heading text-2xl text-green-500 mb-2">Consultation Booked!</h3>
                      <p className="font-body text-foreground/80">
                        Your consultation for {date && format(date, "PPP")} at {timeSlot} is confirmed. You will receive
                        an email with details shortly.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-6 font-body">
                      <div className="grid md:grid-cols-2 gap-6 items-start">
                        <div className="space-y-1.5">
                          <Label className="text-foreground/80">Select Date</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className={`w-full justify-start text-left font-normal border-border/70 bg-secondary/50 hover:bg-accent/50 ${!date && "text-muted-foreground"}`}
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {date ? format(date, "PPP") : "Pick a date"}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0 bg-card border-border shadow-lg">
                              <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                            </PopoverContent>
                          </Popover>
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-foreground/80">Select Time Slot</Label>
                          <Select onValueChange={setTimeSlot} value={timeSlot}>
                            <SelectTrigger className="border-border/70 bg-secondary/50">
                              <SelectValue placeholder="Choose a time" />
                            </SelectTrigger>
                            <SelectContent className="bg-card border-border">
                              {["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM", "04:00 PM"].map((slot) => (
                                <SelectItem key={slot} value={slot}>
                                  {slot}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="consultationNotes" className="text-foreground/80">
                          Additional Notes (Optional)
                        </Label>
                        <Textarea
                          id="consultationNotes"
                          placeholder="Specific topics or questions..."
                          rows={3}
                          className="bg-secondary/50 border-border/70 focus:border-primary"
                        />
                      </div>
                      <Button
                        onClick={handleBookConsultation}
                        disabled={!date || !timeSlot}
                        size="lg"
                        className="w-full"
                      >
                        Book Consultation
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
      </div>
    </div>
  )
}
