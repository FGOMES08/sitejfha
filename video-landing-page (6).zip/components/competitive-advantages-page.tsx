"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Users,
  Settings,
  Award,
  Shield,
  Target,
  Globe,
  CheckCircle,
  Briefcase,
  GitCompareArrows,
  ShieldCheck,
} from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

export default function CompetitiveAdvantagesPage() {
  const [activeAdvantageId, setActiveAdvantageId] = useState<number | null>(1) // Default open first

  const competitiveAdvantages = [
    {
      id: 1,
      title: "Exclusive & Personalized Service",
      icon: <Shield className="w-8 h-8 text-primary" />,
      shortDescription: "Unparalleled commitment to bespoke service with paramount confidentiality and discretion.",
      fullDescription:
        "Our dedication to providing exceptionally personalized service distinguishes us. We prioritize maximum confidentiality and discretion in all operations, ensuring every client receives dedicated attention tailored to their unique circumstances and strategic objectives.",
      keyPoints: [
        "Dedicated senior relationship managers for each client",
        "Bank-grade confidentiality protocols and NDAs",
        "Customized communication strategies and reporting",
        "24/7 availability for critical matters and decisions",
        "Discrete and secure handling of all sensitive information",
        "Success-oriented, long-term partnership approach",
      ],
      benefits: [
        "Enhanced trust and security",
        "Faster, informed decision-making",
        "Reduced operational and reputational risks",
        "Optimized business outcomes",
      ],
    },
    {
      id: 2,
      title: "Bespoke Financial Architectures",
      icon: <Settings className="w-8 h-8 text-primary" />,
      shortDescription:
        "Tailored solutions meticulously designed for each client's unique business environment and goals.",
      fullDescription:
        "JFHA delivers solutions that are always personalized, engineered based on the distinct characteristics of each client and their specific operational and market environment. We recognize that no two businesses are identical, and our approach embodies this core principle.",
      keyPoints: [
        "In-depth business environment and ecosystem analysis",
        "Custom-designed financial structures and instruments",
        "Industry-specific solution architecture and deployment",
        "Proactive regulatory compliance and optimization",
        "Scalable and adaptable implementation frameworks",
        "Continuous performance monitoring and refinement",
      ],
      benefits: [
        "Optimal resource allocation and efficiency",
        "Enhanced competitive market positioning",
        "Improved operational agility and resilience",
        "Sustainable, long-term growth strategies",
      ],
    },
    {
      id: 3,
      title: "Multidisciplinary & Global Expertise",
      icon: <Users className="w-8 h-8 text-primary" />,
      shortDescription:
        "Integrated team of world-class experts across multiple specialized financial and strategic domains.",
      fullDescription:
        "The JFHA consortium comprises seasoned experts in critical areas including international business strategy, cross-border regulation, private equity, advanced risk analytics, and global finance. This multidisciplinary synergy allows for an integrated, holistic approach to all client needs.",
      keyPoints: [
        "International business strategy & market entry specialists",
        "Cross-border regulatory & compliance experts",
        "Private equity & venture capital professionals",
        "Quantitative risk analysis & mitigation strategists",
        "Global finance & treasury management authorities",
        "Seamless cross-functional team collaboration",
      ],
      benefits: [
        "Holistic, 360-degree problem-solving",
        "Reduced implementation and market risks",
        "Accelerated project timelines and value realization",
        "Enhanced strategic foresight and outcomes",
      ],
    },
  ]

  const expertiseBadges = [
    { name: "Business Strategy", icon: <Target className="w-4 h-4 mr-1.5" /> },
    { name: "International Regulation", icon: <Globe className="w-4 h-4 mr-1.5" /> },
    { name: "Private Equity", icon: <Award className="w-4 h-4 mr-1.5" /> },
    { name: "Risk Analysis", icon: <ShieldCheck className="w-4 h-4 mr-1.5" /> },
    { name: "Global Finance", icon: <Briefcase className="w-4 h-4 mr-1.5" /> },
    { name: "M&A Advisory", icon: <GitCompareArrows className="w-4 h-4 mr-1.5" /> },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground section-padding">
      <div className="container-max">
        {/* Hero Section */}
        <section className="text-center mb-16 md:mb-24 fade-in-up">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-gold mb-6">The JFHA Competitive Edge</h1>
          <p className="font-body text-lg md:text-xl text-foreground/80 max-w-4xl mx-auto">
            Explore the unique strengths and strategic differentiators that establish JFHA as the premier partner for
            sophisticated financial advisory and bespoke solutions.
          </p>
        </section>

        {/* Advantages Overview Grid */}
        <section className="mb-16 md:mb-20">
          <div className="grid lg:grid-cols-3 gap-8">
            {competitiveAdvantages.map((advantage, index) => (
              <Card
                key={advantage.id}
                className={cn(
                  "cursor-pointer hover-lift-subtle glass-pane fade-in-up",
                  activeAdvantageId === advantage.id ? "ring-2 ring-primary shadow-elegant-lg" : "border-border/70",
                )}
                onClick={() => setActiveAdvantageId(activeAdvantageId === advantage.id ? null : advantage.id)}
                style={{ animationDelay: `${0.2 + index * 0.1}s` }}
              >
                <CardHeader className="items-center text-center">
                  <div className="p-3 rounded-full bg-primary/10 mb-4">{advantage.icon}</div>
                  <CardTitle className="text-xl md:text-2xl">{advantage.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="font-body text-sm text-foreground/70 mb-4">{advantage.shortDescription}</p>
                  <Button variant="link" size="sm" className="text-primary hover:text-primary/80">
                    {activeAdvantageId === advantage.id ? "Hide Details" : "Learn More"}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Detailed Advantage Section */}
        {activeAdvantageId &&
          competitiveAdvantages.find((adv) => adv.id === activeAdvantageId) &&
          (() => {
            const advantage = competitiveAdvantages.find((adv) => adv.id === activeAdvantageId)!
            return (
              <section className="mb-16 md:mb-24 fade-in-up" style={{ animationDelay: "0.2s" }}>
                <Card className="glass-pane shadow-elegant-md">
                  <CardHeader>
                    <div className="flex items-center mb-3">
                      <div className="p-2 rounded-md bg-primary/10 mr-3">{advantage.icon}</div>
                      <CardTitle className="text-2xl md:text-3xl">{advantage.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="grid md:grid-cols-2 gap-8">
                    <div>
                      <p className="font-body text-md text-foreground/80 mb-6 leading-relaxed">
                        {advantage.fullDescription}
                      </p>
                      <h4 className="font-heading text-lg font-semibold text-white mb-3">Client Benefits:</h4>
                      <div className="flex flex-wrap gap-2">
                        {advantage.benefits.map((benefit, idx) => (
                          <Badge
                            key={idx}
                            variant="secondary"
                            className="border-primary/30 bg-primary/10 text-primary text-xs"
                          >
                            {benefit}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-heading text-lg font-semibold text-white mb-3">Key Features:</h4>
                      <ul className="space-y-2 font-body text-sm text-foreground/70">
                        {advantage.keyPoints.map((point, idx) => (
                          <li key={idx} className="flex items-start">
                            <CheckCircle className="w-4 h-4 text-primary mr-2 mt-0.5 flex-shrink-0" />
                            {point}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              </section>
            )
          })()}

        {/* Expertise Domains Section */}
        <section className="mb-16 md:mb-24">
          <div className="text-center mb-12 md:mb-16 fade-in-up" style={{ animationDelay: "0.2s" }}>
            <h2 className="font-heading text-3xl md:text-4xl text-gold mb-4">Our Expertise Domains</h2>
            <p className="font-body text-lg text-foreground/80 max-w-3xl mx-auto">
              Our multidisciplinary consortium unites world-class expertise across critical business and financial
              domains, ensuring comprehensive, cutting-edge solutions for every client engagement.
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 gap-4 md:gap-6">
            {expertiseBadges.map((area, index) => (
              <Card
                key={index}
                className="text-center fade-in-up hover-lift-subtle glass-pane"
                style={{ animationDelay: `${0.3 + index * 0.05}s` }}
              >
                <CardContent className="p-4 md:p-6">
                  <div className="flex items-center justify-center text-primary mb-2">
                    {area.icon}
                    <h3 className="font-heading text-md md:text-lg font-semibold text-white ml-1.5">{area.name}</h3>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Comparison / Why JFHA Stands Apart Section */}
        <section className="mb-16 md:mb-24">
          <Card className="fade-in-up glass-pane shadow-elegant-md" style={{ animationDelay: "0.2s" }}>
            <CardHeader className="text-center">
              <CardTitle className="text-3xl md:text-4xl">Why JFHA Stands Apart</CardTitle>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 gap-8 md:gap-12">
              <div>
                <h4 className="font-heading text-xl font-semibold text-muted-foreground mb-4">
                  Traditional Firms Often Offer:
                </h4>
                <ul className="space-y-3 font-body text-sm text-muted-foreground">
                  {[
                    "Standardized, one-size-fits-all solutions",
                    "Limited or reactive confidentiality measures",
                    "Siloed expertise with potential knowledge gaps",
                    "Transactional rather than partnership approach",
                  ].map((item) => (
                    <li key={item} className="flex items-start">
                      <span className="text-destructive mr-2 mt-1 flex-shrink-0">&times;</span> {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="border-t md:border-t-0 md:border-l border-border/50 pt-8 md:pt-0 md:pl-8 md:pl-12">
                <h4 className="font-heading text-xl font-semibold text-white mb-4">The JFHA Distinction:</h4>
                <ul className="space-y-3 font-body text-sm text-foreground/80">
                  {[
                    "Fully customized, bespoke financial architectures",
                    "Bank-grade, proactive confidentiality protocols",
                    "Integrated, multidisciplinary global expert teams",
                    "Proactive, strategic long-term partnership model",
                  ].map((item) => (
                    <li key={item} className="flex items-start">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" /> {item}
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* CTA Section */}
        <section className="text-center fade-in-up" style={{ animationDelay: "0.2s" }}>
          <h2 className="font-heading text-3xl md:text-4xl text-gold mb-6">Experience the JFHA Advantage</h2>
          <p className="font-body text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
            Discover how our unique competitive advantages can transform your business outcomes and unlock unprecedented
            opportunities for growth and strategic success.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" passHref>
              <Button size="lg" className="font-body tracking-wide">
                Schedule a Consultation
              </Button>
            </Link>
            <Link href="/services" passHref>
              <Button
                size="lg"
                variant="outline"
                className="font-body tracking-wide border-gold text-gold hover:bg-gold/10"
              >
                Explore Our Services
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  )
}
