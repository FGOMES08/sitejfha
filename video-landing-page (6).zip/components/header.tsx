"use client"

import type React from "react"

import Link from "next/link"
import Image from "next/image"
import { usePathname, useRouter } from "next/navigation"
import { cn } from "@/lib/utils"
import { useState, useEffect } from "react"
import { Search, Menu, X } from "lucide-react"
import { Input } from "@/components/ui/input"

export default function Header() {
  const pathname = usePathname()
  const router = useRouter()
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isSearchActive, setIsSearchActive] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/about", label: "About" },
    { href: "/services", label: "Services" },
    { href: "/advantages", label: "Advantages" },
    { href: "/team", label: "Team" },
    { href: "/process", label: "Process" },
    { href: "/books", label: "Books" }, // Added new link
    { href: "/contact", label: "Contact" },
  ]

  const handleSearchToggle = () => {
    setIsSearchActive((prevIsSearchActive) => {
      const newSearchState = !prevIsSearchActive
      if (!newSearchState) {
        // If search is being closed
        setSearchQuery("")
      }
      return newSearchState
    })
  }

  const handleSearchInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(event.target.value)
  }

  const handleSearchSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (searchQuery.trim()) {
      // Navigate to a search results page with the query
      // You will need to create this page (e.g., app/search/page.tsx)
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
      setIsSearchActive(false) // Close the search input
      setSearchQuery("") // Clear the search input
    }
  }

  // Effect to close mobile menu if search becomes active
  useEffect(() => {
    if (isSearchActive && isMobileMenuOpen) {
      setIsMobileMenuOpen(false)
    }
  }, [isSearchActive, isMobileMenuOpen])

  // Effect to close search if mobile menu becomes active
  useEffect(() => {
    if (isMobileMenuOpen && isSearchActive) {
      setIsSearchActive(false)
      setSearchQuery("")
    }
  }, [isMobileMenuOpen, isSearchActive])

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen)

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out",
        isScrolled ? "bg-background/80 backdrop-blur-lg shadow-elegant-md" : "bg-transparent",
      )}
    >
      <div className="container-max flex items-center justify-between h-20">
        <Link href="/" className="flex items-center group" data-interactive-trail="true">
          <Image
            src="/images/jfha-icon.png"
            alt="JFHA Icon"
            width={96}
            height={96}
            className="transition-transform duration-300 group-hover:scale-110"
            priority
          />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-2">
          {!isSearchActive ? (
            <>
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "relative px-4 py-2 font-body text-sm font-medium rounded-md transition-colors duration-300 group",
                    pathname === link.href
                      ? "text-white bg-primary/10"
                      : "text-foreground/80 hover:text-white hover:bg-primary/5",
                  )}
                  data-interactive-trail="true"
                >
                  {link.label}
                  {pathname === link.href && (
                    <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1/2 h-0.5 bg-primary rounded-t-full"></span>
                  )}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary rounded-t-full transition-all duration-300 group-hover:w-full"></span>
                </Link>
              ))}
              <button
                onClick={handleSearchToggle}
                aria-label="Open search"
                className="p-2.5 rounded-md text-foreground/80 hover:text-white hover:bg-primary/5 transition-colors"
                data-interactive-trail="true"
              >
                <Search size={20} />
              </button>
            </>
          ) : (
            <form onSubmit={handleSearchSubmit} className="flex items-center w-full max-w-sm ml-auto">
              {" "}
              {/* Adjusted max-w and added ml-auto */}
              <Input
                type="search"
                placeholder="Search..."
                value={searchQuery}
                onChange={handleSearchInputChange}
                className="h-10 flex-grow bg-background/50 border-foreground/30 focus:border-primary placeholder:text-foreground/50"
                autoFocus
              />
              <button
                type="submit"
                aria-label="Submit search"
                className="p-2.5 rounded-md text-foreground/80 hover:text-white hover:bg-primary/5 transition-colors ml-2"
              >
                <Search size={20} />
              </button>
              <button
                type="button"
                onClick={handleSearchToggle}
                aria-label="Close search"
                className="p-2.5 rounded-md text-foreground/80 hover:text-white hover:bg-primary/5 transition-colors ml-1"
              >
                <X size={20} />
              </button>
            </form>
          )}
        </nav>

        {/* Mobile Menu Button */}
        <div className="lg:hidden flex items-center">
          {!isSearchActive ? (
            <>
              <button
                onClick={handleSearchToggle}
                aria-label="Open search"
                className="p-2.5 mr-1 rounded-md text-foreground/80 hover:text-white hover:bg-primary/5 transition-colors"
                data-interactive-trail="true"
              >
                <Search size={22} />
              </button>
              <button
                onClick={toggleMobileMenu}
                aria-label="Toggle menu"
                className="p-2.5 rounded-md text-foreground/80 hover:text-white hover:bg-primary/5 transition-colors"
                data-interactive-trail="true"
              >
                {isMobileMenuOpen ? <X size={26} /> : <Menu size={26} />}
              </button>
            </>
          ) : (
            <form onSubmit={handleSearchSubmit} className="flex items-center w-full">
              <Input
                type="search"
                placeholder="Search..."
                value={searchQuery}
                onChange={handleSearchInputChange}
                className="h-10 flex-grow bg-background/50 border-foreground/30 focus:border-primary placeholder:text-foreground/50"
                autoFocus
              />
              <button
                type="submit"
                aria-label="Submit search"
                className="p-2.5 rounded-md text-foreground/80 hover:text-white hover:bg-primary/5 transition-colors ml-2"
              >
                <Search size={22} />
              </button>
              <button
                type="button"
                onClick={handleSearchToggle}
                aria-label="Close search"
                className="p-2.5 rounded-md text-foreground/80 hover:text-white hover:bg-primary/5 transition-colors ml-1"
              >
                <X size={22} />
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && !isSearchActive && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-background/95 backdrop-blur-md shadow-elegant-lg pb-4">
          <nav className="flex flex-col space-y-2 px-4 pt-2">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className={cn(
                  "block px-4 py-3.5 font-body text-base font-medium rounded-md transition-colors duration-300", // Increased py padding
                  pathname === link.href
                    ? "text-white bg-primary/10"
                    : "text-foreground/80 hover:text-white hover:bg-primary/5",
                )}
                data-interactive-trail="true" // Tag for particle interaction
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  )
}
