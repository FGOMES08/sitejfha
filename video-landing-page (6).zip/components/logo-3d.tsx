"use client"

import * as THREE from "three"
import { useState, useEffect, useRef, useMemo } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { Text3D, Center, Float, Environment, Stars } from "@react-three/drei"

type Logo3DProps = {}

function GoldParticles() {
  const particlesRef = useRef<THREE.Points>(null)
  const { mouse, size } = useThree()

  const particleCount = useMemo(() => (size.width < 768 ? 80 : 150), [size.width])

  const positions = useMemo(() => {
    const pos = new Float32Array(particleCount * 3)
    for (let i = 0; i < particleCount; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 15 // x
      pos[i * 3 + 1] = (Math.random() - 0.5) * 10 // y
      pos[i * 3 + 2] = (Math.random() - 0.5) * 8 // z
    }
    return pos
  }, [particleCount])

  const particleMaterial = useMemo(
    () =>
      new THREE.PointsMaterial({
        color: new THREE.Color("#FFD700"),
        size: 0.03,
        transparent: true,
        opacity: 0.7,
        blending: THREE.AdditiveBlending,
        sizeAttenuation: true,
      }),
    [],
  )

  useFrame((state) => {
    if (particlesRef.current) {
      const currentPositions = particlesRef.current.geometry.attributes.position.array as Float32Array
      for (let i = 0; i < particleCount; i++) {
        const i3 = i * 3
        currentPositions[i3 + 1] += Math.sin(state.clock.elapsedTime * 0.5 + i * 0.5) * 0.0015
        currentPositions[i3] += Math.cos(state.clock.elapsedTime * 0.3 + i * 0.3) * 0.001
        currentPositions[i3] += mouse.x * 0.0002
        currentPositions[i3 + 1] += mouse.y * 0.0002
        if (currentPositions[i3 + 1] > 6) currentPositions[i3 + 1] = -6
        if (currentPositions[i3 + 1] < -6) currentPositions[i3 + 1] = 6
      }
      particlesRef.current.geometry.attributes.position.needsUpdate = true
      particlesRef.current.rotation.y += 0.0005
    }
  })

  return (
    <points ref={particlesRef} material={particleMaterial}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={particleCount} array={positions} itemSize={3} />
      </bufferGeometry>
    </points>
  )
}

function Rig() {
  const { camera, mouse } = useThree()
  const vec = new THREE.Vector3()
  return useFrame(() => {
    camera.position.lerp(vec.set(mouse.x * 0.5, mouse.y * 0.25, camera.position.z), 0.02)
    camera.lookAt(0, 0, 0)
  })
}

export default function Logo3D(props: Logo3DProps) {
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  if (!isClient) {
    return (
      <div className="w-full h-full flex items-center justify-center">
        <p className="text-foreground/70 text-lg font-body">Loading 3D Experience...</p>
      </div>
    )
  }

  const refinedGoldMaterial = new THREE.MeshStandardMaterial({
    color: new THREE.Color("#B8860B"),
    metalness: 0.9,
    roughness: 0.25,
    envMapIntensity: 1.2,
  })

  const accentMaterial = new THREE.MeshStandardMaterial({
    color: new THREE.Color("#FFD700"),
    metalness: 1.0,
    roughness: 0.15,
    envMapIntensity: 1.5,
  })

  // IMPORTANT: The following Text3D components require JSON font files.
  // Ensure 'Inter_Bold.json' and 'Inter_Regular.json' (Typeface format)
  // exist in your 'public/fonts/' directory.
  // If these files are missing or paths are incorrect, it will cause loading errors.
  // In some environments like Next.js, these assets might need to be explicitly
  // declared or uploaded to the project.

  return (
    <Canvas camera={{ position: [0, 0, 8], fov: 35 }}>
      <ambientLight intensity={0.6} color="#FFF8DC" />
      <directionalLight position={[5, 8, 5]} intensity={1.0} color="#FFFFFF" castShadow />
      <pointLight position={[-5, -3, 4]} intensity={0.5} color="#FFD700" distance={20} decay={2} />
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={0.5} />
      <Center>
        <Float speed={1.2} rotationIntensity={0.15} floatIntensity={0.15}>
          <group>
            <Text3D
              material={refinedGoldMaterial}
              font="/fonts/Inter_Bold.json" // Path relative to the 'public' directory
              size={1.8}
              height={0.3}
              curveSegments={12}
              bevelEnabled
              bevelThickness={0.05}
              bevelSize={0.03}
              bevelOffset={0}
              bevelSegments={5}
              position={[0, 0, 0]}
            >
              JFHA
            </Text3D>
            <Text3D
              material={accentMaterial}
              font="/fonts/Inter_Regular.json" // Path relative to the 'public' directory
              size={0.5}
              height={0.15}
              curveSegments={10}
              bevelEnabled
              bevelThickness={0.02}
              bevelSize={0.01}
              bevelOffset={0}
              bevelSegments={4}
              position={[0, -0.9, 0]}
            >
              PRIVATE GROUP
            </Text3D>
          </group>
        </Float>
      </Center>
      <GoldParticles />
      <Environment preset="sunset" blur={0.5} background={false} />
      <Rig />
    </Canvas>
  )
}
