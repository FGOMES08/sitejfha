"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { CheckCircle } from "lucide-react"

export default function AdvisorsPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  })
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    setIsSubmitted(true)
    // Reset form after a delay
    setTimeout(() => {
      setIsSubmitted(false)
      setFormData({ name: "", email: "", company: "", message: "" })
    }, 5000)
  }

  return (
    <div className="min-h-screen bg-background text-foreground section-padding">
      <div className="container-max">
        {/* Hero Section */}
        <section className="text-center mb-16 md:mb-24 fade-in-up">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-gold mb-6">JFHA Premium Advisors</h1>
          <p className="font-body text-lg md:text-xl text-foreground/80 max-w-3xl mx-auto">
            Exclusive financial solutions tailored for discerning investors and corporations, driven by ethics,
            precision, and exceptional outcomes.
          </p>
        </section>

        {/* Mission & Why Choose Us Section */}
        <section className="mb-16 md:mb-24 grid lg:grid-cols-2 gap-12 items-center">
          <div className="fade-in-up" style={{ animationDelay: "0.2s" }}>
            <h2 className="font-heading text-3xl md:text-4xl text-gold mb-6">Our Mission</h2>
            <p className="font-body text-lg text-foreground/80 mb-6">
              To connect capital with opportunities through strategic intelligence and unwavering discretion,
              positioning JFHA as a leader in sophisticated business intermediation.
            </p>
            <ul className="space-y-3 font-body text-foreground/80">
              {[
                "Strategic Intelligence & Insight",
                "Absolute Discretion & Confidentiality",
                "Sophisticated Business Intermediation",
                "Ethical & Transparent Practices",
              ].map((item, index) => (
                <li key={index} className="flex items-center">
                  <CheckCircle className="w-5 h-5 text-primary mr-3 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </div>

          <Card className="fade-in-up hover-lift-subtle glass-pane" style={{ animationDelay: "0.4s" }}>
            <CardHeader>
              <CardTitle className="text-2xl md:text-3xl">Why Choose JFHA?</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 font-body text-foreground/80">
                {[
                  "Exclusive access to premium financial opportunities",
                  "Personalized advisory services tailored to your unique needs",
                  "Proven track record of delivering exceptional results",
                  "Unwavering commitment to ethical business practices",
                  "Global network with localized expertise",
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-primary mr-2 mt-1.5 flex-shrink-0">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </section>

        {/* CTA Section */}
        <section className="text-center mb-16 md:mb-24 fade-in-up" style={{ animationDelay: "0.6s" }}>
          <h2 className="font-heading text-3xl md:text-4xl text-gold mb-6">Unlock Your Business Potential</h2>
          <p className="font-body text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
            Ready to explore exclusive financial opportunities? Let's discuss how our premium advisory services can
            elevate your business to new heights of success.
          </p>
          <Button
            size="lg"
            onClick={() => document.getElementById("contact-form-section")?.scrollIntoView({ behavior: "smooth" })}
          >
            Schedule a Consultation
          </Button>
        </section>

        {/* Contact Form Section */}
        <section id="contact-form-section" className="max-w-2xl mx-auto fade-in-up" style={{ animationDelay: "0.8s" }}>
          <Card className="glass-pane">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl md:text-3xl">Connect With Us</CardTitle>
              <p className="font-body text-foreground/70 pt-2">
                Begin a confidential conversation about your financial goals and discover our bespoke solutions.
              </p>
            </CardHeader>
            <CardContent>
              {isSubmitted ? (
                <div className="text-center py-8">
                  <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                  <h3 className="font-heading text-2xl text-green-500 mb-2">Message Sent Successfully!</h3>
                  <p className="font-body text-foreground/80">
                    Thank you for reaching out. We will be in touch shortly.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6 font-body">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-1.5">
                      <Label htmlFor="name" className="text-foreground/80">
                        Full Name
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="e.g., John Doe"
                        required
                        className="bg-secondary/50 border-border/70 focus:border-primary"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="email" className="text-foreground/80">
                        Email Address
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="e.g., john.doe@example.com"
                        required
                        className="bg-secondary/50 border-border/70 focus:border-primary"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="company" className="text-foreground/80">
                      Company/Organization (Optional)
                    </Label>
                    <Input
                      id="company"
                      name="company"
                      value={formData.company}
                      onChange={handleInputChange}
                      placeholder="e.g., Example Corp"
                      className="bg-secondary/50 border-border/70 focus:border-primary"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="message" className="text-foreground/80">
                      Your Message
                    </Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Tell us about your business goals and how we can assist..."
                      required
                      rows={5}
                      className="bg-secondary/50 border-border/70 focus:border-primary"
                    />
                  </div>
                  <Button type="submit" size="lg" className="w-full">
                    Start the Conversation
                  </Button>
                </form>
              )}
              <div className="mt-8 pt-6 border-t border-border/50">
                <p className="text-xs text-foreground/60 text-center">
                  All communications are strictly confidential and protected by our privacy policy. We value your trust.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  )
}
