"use client"

import { useEffect, useState } from "react"
import Image from "next/image"

interface LoadingScreenProps {
  onLoaded: () => void
  minDisplayTime?: number
}

export default function LoadingScreen({ onLoaded, minDisplayTime = 3500 }: LoadingScreenProps) {
  const [animationStep, setAnimationStep] = useState(0)
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const timings = {
      icon: 300,
      jfha: 1000,
      privateGroup: 1400,
      loader: 1800,
    }

    const iconTimer = setTimeout(() => setAnimationStep(1), timings.icon)
    const jfhaTimer = setTimeout(() => setAnimationStep(2), timings.jfha) // This step is visually combined now
    const privateGroupTimer = setTimeout(() => setAnimationStep(3), timings.privateGroup)
    const loaderTimer = setTimeout(() => setAnimationStep(4), timings.loader)
    const loadedTimer = setTimeout(onLoaded, minDisplayTime)

    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval)
          return 100
        }
        return prev + 100 / (minDisplayTime / 50) // 50ms interval
      })
    }, 50)

    return () => {
      clearTimeout(iconTimer)
      clearTimeout(jfhaTimer)
      clearTimeout(privateGroupTimer)
      clearTimeout(loaderTimer)
      clearTimeout(loadedTimer)
      clearInterval(progressInterval)
    }
  }, [onLoaded, minDisplayTime])

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background text-foreground transition-opacity duration-1000 ease-in-out overflow-hidden p-4">
      <style jsx>{`
    .animate-word-drop {
      display: inline-block;
      opacity: 0;
      animation-name: goldBarDrop;
      animation-duration: 0.7s;
      animation-timing-function: cubic-bezier(0.68, -0.55, 0.27, 1.55);
      animation-fill-mode: forwards;
    }
    @keyframes goldBarDrop {
      0% { opacity: 0; transform: translateY(-20px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    .refined-loader {
      width: 48px; /* Adjusted for better balance */
      height: 48px;
      border: 3px solid hsl(var(--primary) / 0.2);
      border-top-color: hsl(var(--primary));
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    .progress-line {
      width: 180px; /* Adjusted */
      height: 2px;
      background: hsl(var(--primary) / 0.15);
      border-radius: 1px;
      overflow: hidden;
    }
    .progress-line-fill {
      height: 100%;
      background: hsl(var(--primary));
      border-radius: 1px;
      transition: width 0.1s linear;
    }
  `}</style>

      {/* Logo and JFHA Text Container */}
      <div
        className={`flex flex-col items-center transition-all duration-1000 ease-in-out mb-3 sm:mb-4 ${
          animationStep >= 1 ? "opacity-100 scale-100" : "opacity-0 scale-90"
        }`}
      >
        <div className="w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 relative mb-2">
          <Image
            src="/images/jfha-icon.png" // Assuming this is the icon part of the logo
            alt="JFHA Icon"
            layout="fill"
            objectFit="contain"
            priority
          />
        </div>
        {/* JFHA text can be part of the icon image or added here if separate */}
        {/* For example, if JFHA is text:
      <h1 className={`font-heading text-4xl sm:text-5xl md:text-6xl text-primary animate-word-drop`} style={{ animationDelay: "0.1s" }}>
        JFHA
      </h1> 
      If it's part of the icon image, the div above is sufficient.
      */}
      </div>

      {/* Private Group Text */}
      <div
        className={`text-center transition-opacity duration-1000 ${animationStep >= 3 ? "opacity-100" : "opacity-0"}`}
      >
        <p className="font-body tracking-wider text-base sm:text-lg md:text-xl">
          <span className="animate-word-drop text-white" style={{ animationDelay: "0.2s" }}>
            PRIVATE
          </span>{" "}
          <span className="animate-word-drop text-white" style={{ animationDelay: "0.5s" }}>
            GROUP
          </span>
        </p>
      </div>

      {/* Loader and Progress */}
      <div
        className={`mt-6 sm:mt-8 flex flex-col items-center space-y-2 sm:space-y-3 ${animationStep >= 4 ? "opacity-100" : "opacity-0"} transition-opacity duration-500`}
      >
        <div className="refined-loader"></div>
        <div className="progress-line">
          <div className="progress-line-fill" style={{ width: `${progress}%` }}></div>
        </div>
        <span className="font-body text-xs text-foreground/60 tracking-widest">LOADING... {Math.round(progress)}%</span>
      </div>
    </div>
  )
}
