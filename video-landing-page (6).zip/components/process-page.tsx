"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, Users, Search, Rocket, HeartHandshake, TrendingUp, Eye, Settings } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

export default function ProcessPage() {
  const [activeStepId, setActiveStepId] = useState<number>(1) // Default open first

  const processSteps = [
    {
      id: 1,
      title: "Initial Consultation & Strategic Alignment",
      icon: <Users className="w-8 h-8 text-primary" />,
      shortDescription: "In-depth understanding of your unique needs, objectives, and strategic profile.",
      description:
        "We commence with a comprehensive strategic consultation to thoroughly understand the unique needs, objectives, and risk profile of each client. This foundational step ensures perfect alignment of expectations with clear, achievable, and ambitious goals.",
      details: [
        "Holistic client profiling and detailed needs assessment.",
        "Strategic goal definition and mutual expectation setting.",
        "Development of a bespoke engagement framework.",
        "Preliminary risk and opportunity landscape evaluation.",
        "Establishment of clear timelines, milestones, and KPIs.",
      ],
      duration: "1-2 Weeks",
    },
    {
      id: 2,
      title: "Rigorous Due Diligence & Analysis",
      icon: <Search className="w-8 h-8 text-primary" />,
      shortDescription: "Exhaustive analysis of all financial, legal, and commercial facets with global compliance.",
      description:
        "Our team conducts a meticulous and exhaustive analysis encompassing all financial, legal, and commercial aspects. This ensures full compliance with the most stringent international regulations and best practices, mitigating risks proactively.",
      details: [
        "Forensic financial statement analysis and verification.",
        "Comprehensive legal structure and compliance review.",
        "In-depth market positioning and competitive landscape analysis.",
        "Multi-faceted risk assessment and mitigation strategy planning.",
        "Global regulatory compliance and ethical standards verification.",
      ],
      duration: "2-4 Weeks",
    },
    {
      id: 3,
      title: "Tailored Solution Execution & Implementation",
      icon: <Rocket className="w-8 h-8 text-primary" />,
      shortDescription: "Development and execution of bespoke solutions with continuous, detailed monitoring.",
      description:
        "We architect and execute highly tailored solutions, accompanied by continuous, granular monitoring and transparent reporting. This ensures effective implementation, agile adaptation, and ultimate success at every stage of the engagement.",
      details: [
        "Custom solution architecture and financial instrument structuring.",
        "Detailed implementation roadmap and project management.",
        "Real-time progress tracking and performance dashboarding.",
        "Proactive stakeholder coordination and communication.",
        "Key performance indicator (KPI) monitoring and optimization.",
      ],
      duration: "4-12 Weeks (Variable)",
    },
    {
      id: 4,
      title: "Post-Implementation Partnership & Optimization",
      icon: <HeartHandshake className="w-8 h-8 text-primary" />,
      shortDescription: "Ongoing support to ensure smooth operations, optimize results, and adapt to market evolution.",
      description:
        "Our commitment extends beyond implementation. We provide dedicated ongoing support to ensure seamless operations, continuously optimize results, and make strategic adjustments as market dynamics and business landscapes evolve, fostering a long-term partnership.",
      details: [
        "Continuous performance monitoring and results analysis.",
        "Regular strategic review and optimization sessions.",
        "Proactive market adaptation and evolution strategies.",
        "Ongoing compliance, governance, and risk management.",
        "Long-term strategic partnership and advisory support.",
      ],
      duration: "Ongoing",
    },
  ]

  const processBenefits = [
    {
      title: "Unwavering Transparency",
      description: "Crystal-clear communication and complete visibility throughout every stage of our engagement.",
      icon: <Eye className="w-8 h-8 text-primary" />,
    },
    {
      title: "Peak Efficiency",
      description: "Streamlined, agile processes meticulously designed to maximize value and minimize time-to-results.",
      icon: <TrendingUp className="w-8 h-8 text-primary" />,
    },
    {
      title: "Profound Expertise",
      description:
        "Seasoned global professionals guiding every step with deep industry knowledge and strategic foresight.",
      icon: <Users className="w-8 h-8 text-primary" />,
    },
    {
      title: "Adaptive Flexibility",
      description:
        "Dynamic, responsive approach that intelligently adapts to evolving market conditions and client needs.",
      icon: <Settings className="w-8 h-8 text-primary" />,
    },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground section-padding">
      <div className="container-max">
        {/* Hero Section */}
        <section className="text-center mb-16 md:mb-24 fade-in-up">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-gold mb-6">
            Our Methodical Approach to Success
          </h1>
          <p className="font-body text-lg md:text-xl text-foreground/80 max-w-4xl mx-auto">
            Our proven methodology ensures exceptional, sustainable results through a structured, transparent, and
            client-centric approach at every stage of our partnership.
          </p>
        </section>

        {/* Process Steps - Interactive List */}
        <section className="mb-16 md:mb-24 grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-4">
            {processSteps.map((step) => (
              <Card
                key={step.id}
                onClick={() => setActiveStepId(step.id)}
                className={cn(
                  "cursor-pointer hover-lift-subtle glass-pane fade-in-up",
                  activeStepId === step.id ? "ring-2 ring-primary shadow-elegant-lg" : "border-border/70",
                )}
                style={{ animationDelay: `${0.2 + step.id * 0.05}s` }}
              >
                <CardHeader className="flex flex-row items-center space-x-4">
                  <div className="p-2 rounded-md bg-primary/10">{step.icon}</div>
                  <div>
                    <CardTitle className="text-lg md:text-xl">{step.title}</CardTitle>
                    <p className="text-xs text-muted-foreground">Duration: {step.duration}</p>
                  </div>
                </CardHeader>
                {activeStepId !== step.id && (
                  <CardContent>
                    <p className="text-sm text-foreground/70 line-clamp-2">{step.shortDescription}</p>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>

          {/* Detailed Step View */}
          <div className="lg:col-span-2">
            {processSteps
              .filter((step) => step.id === activeStepId)
              .map((step) => (
                <Card
                  key={`detail-${step.id}`}
                  className="sticky top-24 glass-pane shadow-elegant-md fade-in-up"
                  style={{ animationDelay: "0.3s" }}
                >
                  <CardHeader>
                    <div className="flex items-center mb-3">
                      <div className="p-3 rounded-md bg-primary/10 mr-4">{step.icon}</div>
                      <div>
                        <p className="text-sm font-semibold text-white uppercase tracking-wider">Step {step.id}</p>
                        <CardTitle className="text-2xl md:text-3xl">{step.title}</CardTitle>
                        <p className="text-sm text-muted-foreground mt-1">Estimated Duration: {step.duration}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="font-body text-md text-foreground/80 mb-6 leading-relaxed">{step.description}</p>
                    <h4 className="font-heading text-lg font-semibold text-white mb-3">
                      Key Activities & Deliverables:
                    </h4>
                    <ul className="space-y-2 font-body text-sm text-foreground/70">
                      {step.details.map((detail, idx) => (
                        <li key={idx} className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
          </div>
        </section>

        {/* Process Benefits Section */}
        <section className="mb-16 md:mb-24">
          <div className="text-center mb-12 md:mb-16 fade-in-up" style={{ animationDelay: "0.2s" }}>
            <h2 className="font-heading text-3xl md:text-4xl text-gold mb-4">Benefits of Our Process</h2>
            <p className="font-body text-lg text-foreground/80 max-w-3xl mx-auto">
              Our refined methodology is engineered to deliver maximum strategic value while upholding the highest
              standards of professionalism, integrity, and client satisfaction.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {processBenefits.map((benefit, index) => (
              <Card
                key={index}
                className="text-center fade-in-up hover-lift-subtle glass-pane"
                style={{ animationDelay: `${0.3 + index * 0.1}s` }}
              >
                <CardHeader className="items-center">
                  <div className="p-3 rounded-full bg-primary/10 mb-3">{benefit.icon}</div>
                  <CardTitle className="text-xl md:text-2xl">{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-body text-sm text-foreground/70">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Client Journey Visualization (Simplified) */}
        <section className="mb-16 md:mb-24">
          <Card className="fade-in-up glass-pane hover-lift-subtle" style={{ animationDelay: "0.2s" }}>
            <CardHeader className="text-center">
              <CardTitle className="text-3xl md:text-4xl">Your Journey to Success with JFHA</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-body text-lg text-foreground/80 max-w-4xl mx-auto mb-10 text-center">
                From initial consultation to ongoing strategic partnership, we are with you every step of the way,
                ensuring your success is our paramount achievement.
              </p>
              <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center px-4">
                {/* Dashed line for larger screens */}
                <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 border-t-2 border-dashed border-primary/30 transform -translate-y-1/2 -z-10"></div>

                {processSteps.map((step, index) => (
                  <div
                    key={step.id}
                    className="flex md:flex-col items-center text-center w-full md:w-1/4 mb-8 md:mb-0 relative px-2"
                  >
                    {/* Vertical line for mobile */}
                    {index < processSteps.length - 1 && (
                      <div className="md:hidden absolute top-8 left-1/2 w-0.5 h-full bg-primary/30 transform -translate-x-1/2 -z-10"></div>
                    )}
                    <div className="p-3 rounded-full bg-primary text-primary-foreground mb-1 md:mb-3 z-10 shadow-md">
                      {step.icon}
                    </div>
                    <h4 className="font-heading text-sm font-semibold text-primary mb-1 md:h-12 flex items-center">
                      {step.title.split("&")[0]}
                    </h4>{" "}
                    {/* Shorten title for viz */}
                    <p className="font-body text-xs text-foreground/70">{step.duration}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {/* CTA Section */}
        <section className="text-center fade-in-up" style={{ animationDelay: "0.2s" }}>
          <h2 className="font-heading text-3xl md:text-4xl text-gold mb-6">Ready to Embark on Your Success Journey?</h2>
          <p className="font-body text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
            Let's initiate a confidential consultation to understand your unique aspirations and explore how our proven
            process can deliver exceptional results for your enterprise.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" passHref>
              <Button size="lg" className="font-body tracking-wide">
                Initiate Your Consultation
              </Button>
            </Link>
            <Link href="/services" passHref>
              <Button
                size="lg"
                variant="outline"
                className="font-body tracking-wide border-gold text-gold hover:bg-gold/10"
              >
                Discover Our Services
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  )
}
