"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Award, ShieldCheck, TrendingUp, Globe, Briefcase, Star, Handshake, Lightbulb } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export default function TeamPage() {
  const founders = [
    {
      name: "André Vieira",
      title: "Director of Operations & Asset Structuring",
      description:
        "A seasoned architect of operational excellence, André masterfully oversees asset structuring, driving efficiency and strategic growth with precision.",
      imageSrc: "/images/andre-vieira.png", // Path to André's image
      icon: <TrendingUp className="w-10 h-10 text-primary" />,
      expertise: [
        "Operations Management",
        "Asset Structuring",
        "Strategic Growth",
        "Process Optimization",
        "Risk Mitigation",
      ],
    },
    {
      name: "Filipe Gomes",
      title: "Director of Strategies & Global Network",
      description:
        "An innovative strategist, Filipe shapes our forward-thinking approaches and expands our global network, ensuring sustained success and market leadership.",
      imageSrc: "/images/filipe-gomes.png", // Path to Filipe's image
      icon: <Globe className="w-10 h-10 text-primary" />,
      expertise: [
        "Strategic Planning",
        "Global Network Development",
        "Innovation Management",
        "International Partnerships",
        "Market Analysis",
      ],
    },
    {
      name: "Jim Teske",
      title: "Director of Legal & Compliance",
      description:
        "A distinguished expert in legal and regulatory landscapes, Jim navigates complexities with acumen, safeguarding our integrity and future success.",
      imageSrc: "/placeholder-xrfgp.png",
      icon: <ShieldCheck className="w-10 h-10 text-primary" />,
      expertise: [
        "Corporate Law",
        "Regulatory Compliance",
        "Risk Management",
        "Corporate Governance",
        "International Law",
      ],
    },
  ]

  const supportTeamAreas = [
    {
      area: "International Finance",
      icon: <Globe className="w-6 h-6 text-primary" />,
      description: "Global financial markets expertise and cross-border transaction specialists.",
    },
    {
      area: "Compliance & Regulatory",
      icon: <ShieldCheck className="w-6 h-6 text-primary" />,
      description: "Ensuring adherence to international standards and best practices.",
    },
    {
      area: "Risk Analysis & Mitigation",
      icon: <Award className="w-6 h-6 text-primary" />,
      description: "Advanced risk assessment and mitigation strategy professionals.",
    },
    {
      area: "Strategic Advisory",
      icon: <Briefcase className="w-6 h-6 text-primary" />,
      description: "Business strategy, corporate development, and market positioning specialists.",
    },
    {
      area: "Financial Structuring",
      icon: <TrendingUp className="w-6 h-6 text-primary" />,
      description: "Complex financial instrument and bespoke structure design experts.",
    },
    {
      area: "Client Relations & Success",
      icon: <Users className="w-6 h-6 text-primary" />,
      description: "Dedicated relationship managers ensuring exceptional client experiences.",
    },
  ]

  const teamValues = [
    {
      title: "Excellence",
      description: "Unwavering commitment to delivering exceptional results and superior quality in every engagement.",
      icon: <Star className="w-8 h-8 text-primary" />,
    },
    {
      title: "Integrity",
      description:
        "Steadfast adherence to the highest ethical standards and transparency in all professional interactions.",
      icon: <Handshake className="w-8 h-8 text-primary" />,
    },
    {
      title: "Innovation",
      description: "Continuous pursuit of pioneering solutions, creative strategies, and forward-thinking approaches.",
      icon: <Lightbulb className="w-8 h-8 text-primary" />,
    },
    {
      title: "Collaboration",
      description:
        "Synergistic teamwork across disciplines to achieve collective success and optimal client objectives.",
      icon: <Users className="w-8 h-8 text-primary" />,
    },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground section-padding">
      <div className="container-max">
        {/* Hero Section */}
        <section className="text-center mb-16 md:mb-24 fade-in-up">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-gold mb-6">Our Esteemed Team</h1>
          <p className="font-body text-lg md:text-xl text-foreground/80 max-w-4xl mx-auto">
            Meet the exceptional leaders and dedicated professionals who drive JFHA's success through profound
            expertise, relentless innovation, and an unwavering commitment to excellence.
          </p>
        </section>

        {/* Founders and Leadership Section */}
        <section className="mb-16 md:mb-24">
          <div className="text-center mb-12 md:mb-16 fade-in-up" style={{ animationDelay: "0.2s" }}>
            <h2 className="font-heading text-3xl md:text-4xl text-gold mb-4">Founders & Visionary Leadership</h2>
            <p className="font-body text-lg text-foreground/80 max-w-3xl mx-auto">
              Our leadership team embodies decades of collective experience across global financial markets, strategic
              planning, and regulatory compliance, guiding JFHA's vision and operational distinction.
            </p>
          </div>
          <div className="grid lg:grid-cols-3 gap-8">
            {founders.map((founder, index) => (
              <Card
                key={index}
                className="fade-in-up hover-lift-subtle glass-pane flex flex-col"
                style={{ animationDelay: `${0.3 + index * 0.1}s` }}
              >
                <CardHeader className="items-center text-center">
                  {/* Container for the image, ensuring it's above the name */}
                  <div className="relative w-36 h-52 sm:w-40 sm:h-56 md:w-44 md:h-64 bg-transparent mb-4 rounded-md overflow-hidden group">
                    {founder.imageSrc ? (
                      <Image
                        src={founder.imageSrc || "/placeholder.svg"}
                        alt={founder.name}
                        layout="fill"
                        objectFit="contain" // Ensures the entire image is visible without cropping, maintains aspect ratio
                        className="transition-transform duration-300 group-hover:scale-105"
                        priority={index < 2} // Prioritize loading for the first two founders' images
                      />
                    ) : (
                      // Fallback to icon if no imageSrc is provided
                      <div className="w-full h-full flex items-center justify-center p-4 bg-primary/5 rounded-md">
                        {founder.icon}
                      </div>
                    )}
                  </div>
                  <CardTitle className="text-xl md:text-2xl">{founder.name}</CardTitle>
                  <p className="font-body text-sm font-semibold text-white">{founder.title}</p>
                </CardHeader>
                <CardContent className="text-center flex-grow flex flex-col justify-between">
                  <p className="font-body text-sm text-foreground/70 mb-6">{founder.description}</p>
                  <div>
                    <h4 className="font-heading text-xs font-semibold text-primary uppercase tracking-wider mb-3">
                      Key Expertise
                    </h4>
                    <div className="flex flex-wrap gap-2 justify-center">
                      {founder.expertise.map((skill, idx) => (
                        <Badge
                          key={idx}
                          variant="secondary"
                          className="border-primary/30 bg-primary/10 text-white text-xs px-2 py-0.5"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Support Team Section */}
        <section className="mb-16 md:mb-24">
          <div className="text-center mb-12 md:mb-16 fade-in-up" style={{ animationDelay: "0.2s" }}>
            <h2 className="font-heading text-3xl md:text-4xl text-gold mb-4">Our Specialist Support Team</h2>
            <p className="font-body text-lg text-foreground/80 max-w-4xl mx-auto">
              Our support team comprises highly qualified and specialized professionals, each contributing a wealth of
              experience from strategic sectors such as international finance, compliance, and risk analysis. With a
              proven track record, they deliver excellence at every juncture.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {supportTeamAreas.map((area, index) => (
              <Card
                key={index}
                className="fade-in-up hover-lift-subtle glass-pane"
                style={{ animationDelay: `${0.3 + index * 0.05}s` }}
              >
                <CardContent className="p-6">
                  <div className="flex items-center mb-3">
                    <div className="p-2 rounded-md bg-primary/10 mr-3">{area.icon}</div>
                    <h3 className="font-heading text-lg font-semibold text-white">{area.area}</h3>
                  </div>
                  <p className="font-body text-sm text-foreground/70">{area.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Team Values Section */}
        <section className="mb-16 md:mb-24">
          <div className="text-center mb-12 md:mb-16 fade-in-up" style={{ animationDelay: "0.2s" }}>
            <h2 className="font-heading text-3xl md:text-4xl text-gold mb-4">Our Guiding Team Values</h2>
            <p className="font-body text-lg text-foreground/80 max-w-3xl mx-auto">
              The core principles that shape our team's culture, approach to every client engagement, and all
              professional interactions.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamValues.map((value, index) => (
              <Card
                key={index}
                className="text-center fade-in-up hover-lift-subtle glass-pane"
                style={{ animationDelay: `${0.3 + index * 0.1}s` }}
              >
                <CardHeader>
                  <div className="mx-auto mb-3">{value.icon}</div>
                  <CardTitle className="text-xl md:text-2xl">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="font-body text-sm text-foreground/70">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Collective Strength Section */}
        <section className="mb-16 md:mb-24">
          <Card className="text-center fade-in-up glass-pane hover-lift-subtle" style={{ animationDelay: "0.2s" }}>
            <CardHeader>
              <CardTitle className="text-3xl md:text-4xl">Our Collective Strength</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-body text-lg text-foreground/80 max-w-4xl mx-auto mb-10">
                Our team's diverse expertise and deeply collaborative ethos empower us to tackle the most complex
                financial challenges, delivering innovative solutions that consistently exceed client expectations.
              </p>
              <div className="grid md:grid-cols-3 gap-8">
                {[
                  {
                    title: "Global Perspective",
                    desc: "International experience across diverse markets and regions.",
                    icon: <Globe className="w-8 h-8 text-primary" />,
                  },
                  {
                    title: "Specialized Expertise",
                    desc: "Profound knowledge in critical financial and strategic domains.",
                    icon: <Award className="w-8 h-8 text-primary" />,
                  },
                  {
                    title: "Collaborative Synergy",
                    desc: "Seamless integration across disciplines for optimal, holistic outcomes.",
                    icon: <Users className="w-8 h-8 text-primary" />,
                  },
                ].map((item, index) => (
                  <div key={index} className="fade-in-up" style={{ animationDelay: `${0.4 + index * 0.1}s` }}>
                    <div className="mx-auto mb-3">{item.icon}</div>
                    <h4 className="font-heading text-lg font-semibold text-white mb-1">{item.title}</h4>
                    <p className="font-body text-sm text-foreground/70">{item.desc}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {/* CTA Section */}
        <section className="text-center fade-in-up" style={{ animationDelay: "0.2s" }}>
          <h2 className="font-heading text-3xl md:text-4xl text-gold mb-6">Partner with Our Expert Team</h2>
          <p className="font-body text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
            Experience the transformative difference that arises from collaborating with a team of seasoned
            professionals wholly dedicated to your enduring success.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" passHref>
              <Button size="lg" className="font-body tracking-wide">
                Schedule a Consultation
              </Button>
            </Link>
            <Link href="/services" passHref>
              <Button
                size="lg"
                variant="outline"
                className="font-body tracking-wide border-gold text-gold hover:bg-gold/10"
              >
                Learn About Our Services
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  )
}
