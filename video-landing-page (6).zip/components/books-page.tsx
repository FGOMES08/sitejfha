"use client"

import Image from "next/image"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Users, Award, BookMarked } from "lucide-react" // Added BookMarked for variety
import Link from "next/link"

interface Book {
  id: string
  title: string
  author: string
  description: string
  coverImageUrl: string
  category: "by-us" | "by-others" | "recommended"
  link?: string // Optional link to purchase or view more
}

const booksData: Book[] = [
  // Books Written by Us
  {
    id: "book-us-1",
    title: "The Art of Strategic Finance",
    author: "JFHA Private Group",
    description:
      "A deep dive into modern financial strategies for corporate growth and wealth management, authored by our leading experts.",
    coverImageUrl: "/placeholder.svg?width=300&height=450",
    category: "by-us",
    link: "#",
  },
  {
    id: "book-us-2",
    title: "Global Market Navigation: An Insider's Guide",
    author: "André Vieira & Filipe Gomes",
    description:
      "Insights from our directors on navigating the complexities of international markets and identifying prime investment opportunities.",
    coverImageUrl: "/placeholder.svg?width=300&height=450",
    category: "by-us",
    link: "#",
  },
  // Books Written by Others (with specific endorsement)
  {
    id: "book-others-1",
    title: "Principles for Dealing with the Changing World Order",
    author: "Ray Dalio",
    description:
      "An essential read, highly recommended by the JFHA team for its insightful analysis of global economic shifts and historical cycles.",
    coverImageUrl: "/placeholder.svg?width=300&height=450",
    category: "by-others",
    link: "#",
  },
  {
    id: "book-others-2",
    title: "Thinking, Fast and Slow",
    author: "Daniel Kahneman",
    description:
      "A profound exploration of cognitive biases and decision-making processes. A cornerstone for strategic thinking at JFHA.",
    coverImageUrl: "/placeholder.svg?width=300&height=450",
    category: "by-others",
    link: "#",
  },
  {
    id: "book-others-3",
    title: "The Black Swan: The Impact of the Highly Improbable",
    author: "Nassim Nicholas Taleb",
    description:
      "A critical work on uncertainty and risk, influential in shaping JFHA's robust risk management frameworks.",
    coverImageUrl: "/placeholder.svg?width=300&height=450",
    category: "by-others",
    link: "#",
  },
  // Recommended Books (Curated List)
  {
    id: "book-rec-1",
    title: "The Intelligent Investor",
    author: "Benjamin Graham",
    description:
      "A timeless classic on value investing, foundational for any serious investor. A core recommendation from JFHA.",
    coverImageUrl: "/placeholder.svg?width=300&height=450",
    category: "recommended",
    link: "#",
  },
  {
    id: "book-rec-2",
    title: "Sapiens: A Brief History of Humankind",
    author: "Yuval Noah Harari",
    description:
      "A captivating account of human history that offers broad perspectives valuable for long-term strategic thinking.",
    coverImageUrl: "/placeholder.svg?width=300&height=450",
    category: "recommended",
    link: "#",
  },
  {
    id: "book-rec-3",
    title: "Influence: The Psychology of Persuasion",
    author: "Robert Cialdini",
    description:
      "Understanding the principles of persuasion is key in negotiations and leadership, a valuable read for professionals.",
    coverImageUrl: "/placeholder.svg?width=300&height=450",
    category: "recommended",
    link: "#",
  },
]

const BookCard = ({ book }: { book: Book }) => (
  <Card className="flex flex-col h-full glass-pane hover-lift-subtle fade-in-up">
    <CardHeader className="p-0 relative aspect-[2/3] w-full overflow-hidden rounded-t-lg">
      <Image
        src={book.coverImageUrl || "/placeholder.svg"}
        alt={`Cover of ${book.title}`}
        layout="fill"
        objectFit="cover"
        className="transition-transform duration-300 group-hover:scale-105"
      />
    </CardHeader>
    <CardContent className="flex flex-col flex-grow p-4 md:p-6">
      <h3 className="font-heading text-lg md:text-xl font-semibold text-gold mb-1 leading-tight">{book.title}</h3>
      <p className="font-body text-sm text-foreground/70 mb-3">By {book.author}</p>
      <p className="font-body text-sm text-foreground/80 flex-grow mb-4">{book.description}</p>
      {book.link && (
        <Button variant="outline" size="sm" asChild className="mt-auto border-gold text-gold hover:bg-gold/10">
          <Link href={book.link} target="_blank" rel="noopener noreferrer">
            Learn More
          </Link>
        </Button>
      )}
    </CardContent>
  </Card>
)

const renderBookGrid = (category: Book["category"]) => {
  const filteredBooks = booksData.filter((book) => book.category === category)
  if (filteredBooks.length === 0) {
    return <p className="text-center text-foreground/70 py-8">No books in this section yet. Check back soon!</p>
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
      {filteredBooks.map((book, index) => (
        <div key={book.id} style={{ animationDelay: `${0.1 + index * 0.05}s` }}>
          <BookCard book={book} />
        </div>
      ))}
    </div>
  )
}

const BooksPage = () => {
  return (
    <div className="min-h-screen bg-background text-foreground section-padding">
      <div className="container-max">
        {/* Hero Section */}
        <section className="text-center mb-16 md:mb-24 fade-in-up">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-gold mb-6">Literary Insights</h1>
          <p className="font-body text-lg md:text-xl text-foreground/80 max-w-3xl mx-auto">
            Explore a curated collection of books from our experts and influential works that shape our strategic
            thinking and financial acumen.
          </p>
        </section>

        {/* Tabs for Book Categories */}
        <Tabs defaultValue="by-us" className="w-full fade-in-up" style={{ animationDelay: "0.2s" }}>
          <TabsList className="grid w-full grid-cols-1 sm:grid-cols-3 gap-2 mb-8 md:mb-12 bg-secondary p-1 rounded-lg">
            <TabsTrigger
              value="by-us"
              className="font-body data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md hover:bg-primary/10 transition-all py-2.5"
            >
              <Users className="w-5 h-5 mr-2" /> By Our Team
            </TabsTrigger>
            <TabsTrigger
              value="by-others"
              className="font-body data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md hover:bg-primary/10 transition-all py-2.5"
            >
              <Award className="w-5 h-5 mr-2" /> Endorsed by JFHA
            </TabsTrigger>
            <TabsTrigger
              value="recommended"
              className="font-body data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md hover:bg-primary/10 transition-all py-2.5"
            >
              <BookMarked className="w-5 h-5 mr-2" /> Recommended Reading
            </TabsTrigger>
          </TabsList>

          <TabsContent value="by-us" className="fade-in-up" style={{ animationDelay: "0.3s" }}>
            <h2 className="font-heading text-2xl md:text-3xl text-gold mb-6 md:mb-8 text-center">
              Authored by Our Experts
            </h2>
            {renderBookGrid("by-us")}
          </TabsContent>
          <TabsContent value="by-others" className="fade-in-up" style={{ animationDelay: "0.3s" }}>
            <h2 className="font-heading text-2xl md:text-3xl text-gold mb-6 md:mb-8 text-center">Endorsed by JFHA</h2>
            {renderBookGrid("by-others")}
          </TabsContent>
          <TabsContent value="recommended" className="fade-in-up" style={{ animationDelay: "0.3s" }}>
            <h2 className="font-heading text-2xl md:text-3xl text-gold mb-6 md:mb-8 text-center">
              Curated Recommendations
            </h2>
            {renderBookGrid("recommended")}
          </TabsContent>
        </Tabs>

        {/* CTA to contact for more recommendations or discussions */}
        <section className="mt-16 md:mt-24 text-center fade-in-up" style={{ animationDelay: "0.4s" }}>
          <h2 className="font-heading text-3xl md:text-4xl text-gold mb-6">Expand Your Knowledge</h2>
          <p className="font-body text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
            Interested in more tailored recommendations or discussing these works? Our team is always ready to share
            insights.
          </p>
          <Link href="/contact" passHref>
            <Button size="lg" className="font-body tracking-wide">
              Connect With Our Experts
            </Button>
          </Link>
        </section>
      </div>
    </div>
  )
}

export default BooksPage
