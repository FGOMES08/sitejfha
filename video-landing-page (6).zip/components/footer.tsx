"use client"

import Link from "next/link"
import Image from "next/image"
import { Facebook, Linkedin, Twitter, Youtube, Mail, Phone, MapPin } from "lucide-react"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  const socialLinks = [
    { name: "Facebook", icon: <Facebook size={20} />, href: "#" },
    { name: "LinkedIn", icon: <Linkedin size={20} />, href: "#" },
    { name: "Twitter", icon: <Twitter size={20} />, href: "#" },
    { name: "YouTube", icon: <Youtube size={20} />, href: "#" },
  ]

  const footerNav = [
    {
      title: "Company",
      links: [
        { label: "About Us", href: "/about" },
        { label: "Our Team", href: "/team" },
        { label: "Careers", href: "#" },
        { label: "Press", href: "#" },
      ],
    },
    {
      title: "Services",
      links: [
        { label: "Strategic Consulting", href: "/services" },
        { label: "Financial Instruments", href: "/services" },
        { label: "Capital Advisory", href: "/services" },
        { label: "Our Process", href: "/process" },
      ],
    },
    {
      title: "Resources",
      links: [
        { label: "Blog", href: "#" },
        { label: "Case Studies", href: "#" },
        { label: "FAQ", href: "/contact#faq" },
        { label: "Downloads", href: "#" },
      ],
    },
  ]

  return (
    <footer className="bg-secondary text-secondary-foreground/80 border-t border-border/50">
      <div className="container-max py-6 md:py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div className="space-y-4">
            <Link href="/" className="flex items-center group">
              <Image
                src="/images/jfha-icon.png"
                alt="JFHA Icon"
                width={40}
                height={40}
                className="transition-transform duration-300 group-hover:scale-110"
              />
              <span className="ml-3 text-lg font-heading font-semibold text-gold group-hover:text-primary/80 transition-colors">
                JFHA Private Group
              </span>
            </Link>
            <p className="text-sm">Connecting capital and opportunities with strategic intelligence and discretion.</p>
            <div className="space-y-2 text-sm">
              <a
                href="mailto:contato@jfha.com.br"
                className="flex items-center hover:text-white transition-colors py-1"
              >
                <Mail size={16} className="mr-2 flex-shrink-0" /> contato@jfha.com.br
              </a>
              <a href="tel:+5511XXXXXXX" className="flex items-center hover:text-white transition-colors py-1">
                <Phone size={16} className="mr-2 flex-shrink-0" /> (+55 11) XXXX-XXXX
              </a>
              <p className="flex items-start py-1">
                <MapPin size={16} className="mr-2 mt-0.5 flex-shrink-0" />
                <span>
                  Barueri, São Paulo, Brazil (HQ) <br /> & Strategic Locations
                </span>
              </p>
            </div>
          </div>

          {footerNav.map((section) => (
            <div key={section.title}>
              <h5 className="font-heading text-lg font-semibold text-gold mb-4">{section.title}</h5>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-sm hover:text-white hover:underline transition-colors py-1 inline-block"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-border/50 pt-8 flex flex-col md:flex-row justify-between items-center text-sm">
          <p>&copy; {currentYear} JFHA Private Group. All rights reserved.</p>
          <div className="flex items-center space-x-1 mt-4 md:mt-0">
            {" "}
            {/* Reduced space-x for tighter packing if needed */}
            {socialLinks.map((social) => (
              <a
                key={social.name}
                href={social.href}
                aria-label={social.name}
                className="p-2.5 block rounded-md hover:text-white hover:bg-primary/10 transition-colors" // Increased padding and made block
              >
                <span className="sr-only">{social.name}</span>
                {social.icon}
              </a>
            ))}
          </div>
          <div className="mt-4 md:mt-0 space-x-4">
            <Link
              href="/privacy-policy"
              className="hover:text-white hover:underline transition-colors py-1 inline-block"
            >
              Privacy Policy
            </Link>
            <Link
              href="/terms-of-service"
              className="hover:text-white hover:underline transition-colors py-1 inline-block"
            >
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
