import AdvisorsPage from "@/components/advisors-page"

export default function Advisors() {
  return <AdvisorsPage />
}
