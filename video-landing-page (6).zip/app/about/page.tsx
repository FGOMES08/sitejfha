import AboutPage from "@/components/about-page"

export default function About() {
  return <AboutPage />
}
