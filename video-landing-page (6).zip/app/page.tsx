"use client"

import { useState, useEffect } from "react"
import LoadingScreen from "@/components/loading-screen"
import { Button } from "@/components/ui/button"
import { ArrowDown } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function HomePage() {
  const [isLoading, setIsLoading] = useState(true)
  const [showMainContent, setShowMainContent] = useState(false)

  const handleLoadingComplete = () => {
    setIsLoading(false)
    setTimeout(() => {
      setShowMainContent(true)
    }, 100)
  }

  useEffect(() => {
    if (!isLoading && !showMainContent) {
      setShowMainContent(true)
    }
  }, [isLoading, showMainContent])

  return (
    <>
      {isLoading && <LoadingScreen onLoaded={handleLoadingComplete} minDisplayTime={3500} />}

      <div
        className={`transition-opacity duration-1000 ease-in-out ${showMainContent ? "opacity-100" : "opacity-0"}`}
        style={{ visibility: showMainContent ? "visible" : "hidden" }}
      >
        {/* Hero Section */}
        <section className="relative w-screen h-screen overflow-hidden flex flex-col items-center justify-center p-4 sm:p-6 md:p-8">
          {/* Video Background */}
          <div className="absolute inset-0 z-0">
            <video
              autoPlay
              loop
              muted
              playsInline
              className="absolute top-0 left-0 w-full h-full object-cover"
              poster="/images/logo-reference.png"
            >
              <source src="/videos/background-video.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
            <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/70 to-background"></div>
          </div>

          {/* Content Wrapper */}
          <div className="relative z-10 flex flex-col items-center justify-center text-center w-full max-w-5xl">
            {/* Static Logo Container */}
            <div
              className="w-full max-w-[180px] xs:max-w-[220px] sm:max-w-[280px] md:max-w-[320px] lg:max-w-[380px] mb-2 sm:mb-4 md:mb-6 fade-in-up"
              style={{ animationDelay: "0.2s" }}
              data-interactive-trail="true" // Tag logo for particle interaction
            >
              <Image
                src="/images/jfha-static-logo.png"
                alt="JFHA Private Group Logo"
                width={600}
                height={600} // Assuming a square aspect ratio for the logo image
                layout="responsive"
                priority
              />
            </div>

            {/* Hero Text */}
            <div className="fade-in-up" style={{ animationDelay: "0.4s" }}>
              <p className="text-sm xs:text-base sm:text-lg md:text-xl lg:text-2xl text-foreground/80 max-w-xs sm:max-w-md md:max-w-2xl lg:max-w-3xl mx-auto mb-6 sm:mb-8 md:mb-10 px-2 sm:px-4">
                Connecting capital and opportunities with strategic intelligence, discretion, and unparalleled elegance.
              </p>
            </div>

            {/* Call to Action Buttons */}
            <div
              className="flex flex-col xs:flex-row gap-3 sm:gap-4 md:gap-6 fade-in-up"
              style={{ animationDelay: "0.6s" }}
            >
              <Link href="/services" passHref>
                <Button
                  variant="default"
                  size="lg"
                  className="font-body tracking-wide text-xs xs:text-sm sm:text-base px-4 py-2 sm:px-6 md:px-8"
                  data-interactive-trail="true" // Tag button for particle interaction
                >
                  Explore Our Services
                </Button>
              </Link>
              <Link href="/contact" passHref>
                <Button
                  variant="outline"
                  size="lg"
                  className="font-body tracking-wide border-gold text-gold hover:bg-gold/10 text-xs xs:text-sm sm:text-base px-4 py-2 sm:px-6 md:px-8"
                  data-interactive-trail="true" // Tag button for particle interaction
                >
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>

          {/* Scroll Down Indicator */}
          <div
            className="absolute bottom-6 sm:bottom-8 md:bottom-10 left-1/2 transform -translate-x-1/2 z-10 fade-in-up"
            style={{ animationDelay: "0.8s" }}
          >
            <button
              onClick={() => {
                const nextSection = document.getElementById("next-section")
                if (nextSection) {
                  nextSection.scrollIntoView({ behavior: "smooth" })
                } else {
                  window.scrollTo({ top: window.innerHeight, behavior: "smooth" })
                }
              }}
              aria-label="Scroll down"
              className="p-2 text-foreground/70 hover:text-primary transition-colors animate-bounce"
              data-interactive-trail="true" // Tag scroll button
            >
              <ArrowDown size={24} sm={28} />
            </button>
          </div>
        </section>

        {/* Placeholder for subsequent sections */}
        <section id="next-section" className="section-padding bg-secondary">
          <div className="container-max text-center">
            <h2 className="font-heading text-3xl md:text-4xl text-gold mb-4">Our Expertise</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
              Discover how our tailored financial solutions and strategic advisory can elevate your business.
            </p>
          </div>
        </section>
      </div>
    </>
  )
}
