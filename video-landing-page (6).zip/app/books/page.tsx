import BooksPage from "@/components/books-page"

export default function Books() {
  return <BooksPage />
}
