import ContactPage from "@/components/contact-page"

export default function Contact() {
  return <ContactPage />
}
