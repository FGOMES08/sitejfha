import localFont from "next/font/local"

// Define Wallington Pro as the primary font for body text
const wallingtonPro = localFont({
  src: [
    {
      path: "./WallingtonPro-Regular.woff2", // Path relative to this fonts.ts file
      weight: "400",
      style: "normal",
    },
  ],
  variable: "--font-primary", // CSS variable for body text
  display: "swap",
})

// Define ROYALE SEMIBOLD as the font for headings
const royaleSemibold = localFont({
  src: [
    {
      path: "./ROYALESemibold.woff", // Path relative to this fonts.ts file
      weight: "600", // Assuming 'Semibold' corresponds to weight 600
      style: "normal",
    },
  ],
  variable: "--font-heading-royale", // CSS variable for headings
  display: "swap",
})

export { wallingtonPro, royaleSemibold }
