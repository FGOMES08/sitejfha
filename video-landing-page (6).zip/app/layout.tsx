import type React from "react"
import type { Metadata } from "next"
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { ThemeProvider } from "@/components/theme-provider"
import { wallingtonPro, royaleSemibold } from "@/app/fonts/fonts" // Updated import
import MouseTrail from "@/components/mouse-trail"

export const metadata: Metadata = {
  title: "JFHA Private Group - Premier Financial Advisory",
  description:
    "JFHA Private Group: Connecting capital and opportunities with strategic intelligence, discretion, and unparalleled elegance.",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${wallingtonPro.variable} ${royaleSemibold.variable}`} suppressHydrationWarning>
      <body className="font-primary">
        {" "}
        {/* Default body font set here via Tailwind utility */}
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow pt-20">{children}</main>
            <Footer />
            <MouseTrail />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}
