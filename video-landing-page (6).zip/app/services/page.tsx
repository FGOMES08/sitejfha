import ServicesPage from "@/components/services-page"

export default function Services() {
  return <ServicesPage />
}
