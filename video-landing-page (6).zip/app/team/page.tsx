import TeamPage from "@/components/team-page"

export default function Team() {
  return <TeamPage />
}
