import CompetitiveAdvantagesPage from "@/components/competitive-advantages-page"

export default function CompetitiveAdvantages() {
  return <CompetitiveAdvantagesPage />
}
