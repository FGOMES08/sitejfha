import ProcessPage from "@/components/process-page"

export default function Process() {
  return <ProcessPage />
}
